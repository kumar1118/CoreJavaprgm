//develop a program which has to explain flow of recursive algo.
class M24 
{
	static void print(int count)
	{
	System.out.println("print:"+count+":begin");
	count++;
	if(count <= 5)
		{
		print(count);
		}
		System.out.println("print:"+count+":end");
	}

	public static void main(String[] args) 
	{
		System.out.println("main begin");
		print(1);
		System.out.println("main end");
	}
}
//main begin
//print:1begin
//print:2begin
//print:3begin
//print:4begin
//print:5begin
//print:6end
//print:5end
//print:4end
//print:3end
//print:2end
//main:end