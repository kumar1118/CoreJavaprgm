//Read an array content in the reverse order.

import java.util.Arrays;
class  M8
{
	public static void main(String[] args) 
	{
		int[] x ={ 1,4,9,10,6,20,15};
		for(int i = x.length -1; i >= 0; i--)
		{
		System.out.print(x[i] +",");
		}
		System.out.println();
		System.out.println(Arrays.toString(x));
	}
}

//15,20,6,10,9,4,1