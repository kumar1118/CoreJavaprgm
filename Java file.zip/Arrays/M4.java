//print boolean values of an array by using arrays class.

class  M4
{
	public static void main(String[] args) 
	{
		boolean[] x = new boolean[7];
		for(boolean flag : x)
		{
		System.out.print(flag + ",");
		}
		System.out.println();
		System.out.println("...........");
	}
}