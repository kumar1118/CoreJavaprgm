//Define an array with initial values as desired values.

import java.util.Arrays;
class M7 
{
	public static void main(String[] args) 
	{
		int[] x = {10,20,5,22,89,100};
		System.out.println(Arrays.toString(x));
	}
}
// [10,20,5,22,89,100]