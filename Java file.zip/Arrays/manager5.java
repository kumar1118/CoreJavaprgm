//print default values of an array by using arrays class.
import java.util.Arrays;
class  Manager5
{
	public static void main(String[] args) 
	{
		int[] x = new int[10];
		System.out.println(Arrays.toString(x));
	}
}


//[0,0,0,0,0,0,0,0,0,0]