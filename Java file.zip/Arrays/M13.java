//Left shift by one in the given int array.


import java.util.Arrays;
class  M13
{
	public static void main(String[] args) 
	{
		int[] x = {10,3,20,5,11,23,15};
		System.out.println("given array:"+ Arrays.toString(x));
		for(int i = 0; i < x.length - 1; i++)
		{
			x[i] = x[i+1];
		}		
		
		System.out.println("after left shift:"+ Arrays.toString(x));
	}
}
//given array:[10,3,20,5,11,23,15]
//after left shift:[3,20,5,11,23,15,15] 
//first itiration :3,3,20,5,11,23,15
//second itiration :3,20,20,5,11,23,15
//third itiration :3,20,5,5,11,23,15
//fourth itiration :3,20,5,11,11,23,15
//fifth itiration :3,20,5,11,23,23,15
//sixth itiration :3,20,5,11,23,15,15









