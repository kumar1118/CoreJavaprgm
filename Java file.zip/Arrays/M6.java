//Read size of an array from the customer and elements of an array and print all elements.
import java.util.Scanner;
import java.util.Arrays;
class M6 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size of an array");
		int size = sc.nextInt();
		int[] x = new int[size];
		for(int i = 0; i <x.length; i++)
		{
		System.out.println("enter an int values for" + i + "index");
		x[i] = sc.nextInt();
		}
		System.out.println("array content:"+ Arrays.toString(x));
	}
}

//enter size of an array
//5
//enter an int values for0index
//10
//enter an int values for1index
//50
//enter an int values for2index
//30
//enter an int values for3index
//20
//enter an int values for4index
//80
//array content:[10,50,30,20,80]