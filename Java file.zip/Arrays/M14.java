//Left rotate by one in the given int array.


import java.util.Arrays;
class  M14
{
	public static void main(String[] args) 
	{
		int[] x = {10,3,20,5,11,23,15};
		System.out.println("given array:"+ Arrays.toString(x));
		int temp = x[0];
		for(int i = 0; i < x.length - 1; i++)
		{
			x[i] = x[i+1];
		}		
		x[x.length - 1] = temp;
		System.out.println("after left rotate:"+ Arrays.toString(x));
	}
}
//given array:[10,3,20,5,11,23,15]
//after left rotate:[3,20,5,11,23,15,10] 
//first itiration :3,3,20,5,11,23,15
//second itiration :3,20,20,5,11,23,15
//third itiration :3,20,5,5,11,23,15
//fourth itiration :3,20,5,11,11,23,15
//fifth itiration :3,20,5,11,23,23,15
//sixth itiration :3,20,5,11,23,15,15
//seventh itiration :3,20,5,11,23,15,10











