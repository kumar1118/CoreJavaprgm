// print 1 to 10 without any loop.

class M23 
{
	static void print(int i)
		{
		System.out.println(i);
		i++;
		if(i <=10)
			{
			print(i);//calling and assigning i
			}
		}
	public static void main(String[] args) 
	{
		print(1);//calling and assigning i
	}
}

//1
//2
//3
//4
//5
//6
//7
//8
//9
//10