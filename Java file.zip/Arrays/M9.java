//Find out the sum of all int elements from a given array.
//import java.util.Scanner;
import java.util.Arrays;
class M9
{
	public static void main(String[] args) 
	{
		int[] x = {10,3,20,8,40,18};
		System.out.println("given array:"+ Arrays.toString(x));
		int sum = 0;
		for(int i : x)
		{
			sum += i;
		}
		System.out.println("sum:"+ sum);
	}
}
//given array:{