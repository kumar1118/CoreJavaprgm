class  M27// in areverse no
{
	static void print(int index, int[] array)
	{
		if(index == -1)
		{
			return;
		}
System.out.print(array[index --] + " ,");
		 print(index,array);
		
	}
	 public static void main(String[] args)
	{
		int[] array = { 1, 4, 8, 2, 5, 0, 9, 6};
		print(array.length - 1 , array);
	}
}
