package lara.rst;

class  D
{
	public static void main(String[] args) 
	{
		System.out.println("from lara.rst.D");
	}
}
