//Pattern 2 : yyyy-MM-dd (Ex : 2016-09-10)


import java.text.SimpleDateFormat;
import java.util.Date;
 
public class E2
{
    public static void main(String[] args) 
    {
        //Getting today's date
         
        Date today = new Date();
         
        //Printing today's date in the default format
         
        System.out.println("Today is : "+today);
         
        //Formatting today's date in yyyy-MM-dd format
         
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
         
        System.out.println("Today in yyyy-MM-dd format : "+formatter.format(today));
    }
}
Output :

Today is : Sat Jan 28 11:29:26 IST 2017
Today in yyyy-MM-dd format : 2017-01-28
