//Pattern 6 : EEEE, MMM dd yyyy, hh:mm:ss a (Ex : Saturday, Sep 10 2016, 06:45:51 PM)


import java.text.SimpleDateFormat;
import java.util.Date;
 
class G
{
    public static void main(String[] args) 
    {
        //Getting today's date
         
        Date today = new Date();
         
        //Printing today's date in the default format
         
        System.out.println("Today is : "+today);
         
        //Formatting today's date in EEEE, MMM dd yyyy, hh:mm:ss a format
         
        SimpleDateFormat formatter = new SimpleDateFormat("EEEE, MMM dd yyyy, hh:mm:ss a");
         
        System.out.println("Today in EEEE, MMM dd yyyy, hh:mm:ss a format : "+formatter.format(today));
    }
}
//Output :

//Today is : Sat Jan 28 11:53:14 IST 2017
//Today in EEEE, MMM dd yyyy, hh:mm:ss a format : Saturday, Jan 28 2017, 11:53:14 AM
