//Pattern 8 : dd-MMM-yyyy HH:mm:ss Z (Ex : 10-Sep-2016 19:01:39 +0530)


import java.text.SimpleDateFormat;
import java.util.Date;
 
class I
{
    public static void main(String[] args) 
    {
        //Getting today's date
         
        Date today = new Date();
         
        //Printing today's date in the default format
         
        System.out.println("Today is : "+today);
         
        //Formatting today's date in dd-MMM-yyyy HH:mm:ss Z format
         
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss Z");
         
        System.out.println("Today in dd-MMM-yyyy HH:mm:ss Z format : "+formatter.format(today));
    }
}
Output :

Today is : Sat Sep 10 19:01:39 IST 2016
Today in dd-MMM-yyyy HH:mm:ss Z format : 10-Sep-2016 19:01:39 +0530