//Pattern 7 : dd-MMM-yyyy HH:mm:ss z (Ex : 10-Sep-2016 18:49:53 IST)


import java.text.SimpleDateFormat;
import java.util.Date;
 
class H
{
    public static void main(String[] args) 
    {
        //Getting today's date
         
        Date today = new Date();
         
        //Printing today's date in the default format
         
        System.out.println("Today is : "+today);
         
        //Formatting today's date in dd-MMM-yyyy HH:mm:ss z format
         
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss z");
         
        System.out.println("Today in dd-MMM-yyyy HH:mm:ss z format : "+formatter.format(today));
    }
}

//Today is : Sat Jan 28 11:57:01 IST 2017
//Today in dd-MMM-yyyy HH:mm:ss z format : 28-Jan-2017 11:57:01 IST