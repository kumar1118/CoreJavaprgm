//Array To ArrayList In Java :
//Using Arrays.asList() Method :

import java.util.ArrayList;
import java.util.Arrays;
 
public class D1
{      
    public static void main(String[] args) 
    {    
        String[] array = new String[] {"ANDROID", "JSP", "JAVA", "STRUTS", "HADOOP", "JSF"};
         
        ArrayList<String> list = new ArrayList<String>(Arrays.asList(array));
         
        System.out.println(list);
    }    
}

[ANDROID, JSP, JAVA, STRUTS, HADOOP, JSF]
