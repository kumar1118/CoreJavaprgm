//Pattern 5 : dd-MMM-yyyy HH:mm:ss (Ex : 10-Sep-2016 18:40:47)


import java.text.SimpleDateFormat;
import java.util.Date;
 
public class E33
{
    public static void main(String[] args) 
    {
        //Getting today's date
         
        Date today = new Date();
         
        //Printing today's date in the default format
         
        System.out.println("Today is : "+today);
         
        //Formatting today's date in dd-MMM-yyyy HH:mm:ss format
         
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
         
        System.out.println("Today in dd-MMM-yyyy HH:mm:ss format : "+formatter.format(today));
    }
}