 //Pattern 1 : dd/MM/yyyy (Ex : 10/09/2016)


import java.text.SimpleDateFormat;
import java.util.Date;
 
public class E1
{
    public static void main(String[] args) 
    {
        //Getting today's date
         
        Date today = new Date();
         
        //Printing today's date in the default format
         
        System.out.println("Today is : "+today);
         
        //Formatting today's date in dd/MM/yyyy format
         
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
         
        System.out.println("Today in dd/MM/yyyy format : "+formatter.format(today));
    }
}
Output :

Today is : Sat Jan 28 11:24:34 IST 2017
Today in dd/MM/yyyy format : 28/01/2017