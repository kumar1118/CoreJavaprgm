//Pattern 5 : dd-MMM-yyyy HH:mm:ss (Ex : 10-Sep-2016 18:40:47)
import java.text.SimpleDateFormat;
//import java.util.Arrays;
import java.util.Date;
class F 
{
 public static void main(String[] args) 
    {
        //Getting today's date
         
        Date today = new Date();
         
        //Printing today's date in the default format
         
        System.out.println("Today is : "+today);
         
        //Formatting today's date in dd-MMM-yyyy HH:mm:ss format
         
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
         
        System.out.println("Today in dd-MMM-yyyy HH:mm:ss format : "+formatter.format(today));
    }
}


//Today is : Sat Jan 28 11:46:26 IST 2017
//Today in dd-MMM-yyyy HH:mm:ss format : 28-Jan-2017 11:46:26
