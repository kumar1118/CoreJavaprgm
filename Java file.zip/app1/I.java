class I
{
	public static void main(String[] args) 
	{
		for(char i = 'm'; i <= 'r';i++)
			{
		for(char j = i; j<='r'; j++)
			{
				if(j>i)
				{
				System.out.print(" ");
				}
				else
				{
		System.out.print(j);
				}
			}
			System.out.println();
			}
	}
}
//m
//mn
//mno
//mnop
//mnopq
//mnopqr