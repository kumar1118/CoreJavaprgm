class QG
{
	public static void main(String[] args) 
	{
		for(char i = 'm'; i <= 'r';i++)
			{
		for(char j = 'm'; j<='r'; j++)
			{
				if(j<i)
				{
				System.out.print(" ");
				}
				else
				{
		System.out.print(j);
				}
			}
			System.out.println();
			}
	}
}
//mnopqr
///nopqr
////opqr
/////pqr
//////qr
///////r