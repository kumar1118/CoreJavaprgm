class B 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		System.out.println(10000);
		System.out.println(10.989000);
		System.out.println(a);
		System.out.println(p);
		System.out.println(%);
		System.out.println(true);
		System.out.println(false);
	}
}
// Error due to %