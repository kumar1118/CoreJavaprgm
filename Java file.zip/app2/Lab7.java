class Lab7 
{
	public static void main(String[] args) 
	{
		String str;
		str= "JLC";
		System.out.println(str);
	}
}
