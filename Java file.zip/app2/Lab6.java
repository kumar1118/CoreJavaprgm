class  Lab6
{
	int a;
	public static void main(String[] args) 
	{
		System.out.println(a);
	}
}
