class lab23 
{
	public static void main(String[] args) 
	{
		final int A;
		A= 99;
		System.out.println(A);
	}
}
