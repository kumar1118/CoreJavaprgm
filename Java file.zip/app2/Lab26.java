class Lab26 
{
	public static void main(String[] args) 
	{
		final int A;
		A = 99;
		System.out.println(A);
		A = 98;
		System.out.println(A);
	}
}
