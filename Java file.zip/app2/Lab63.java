class Lab63 
{
	public static void main(String[] args) 
	{
		int a = '\u0061';
		int b = '\u0062';
		System.out.println(a);
		System.out.println(b);
		int c = '\u0041';
		int d = '\u0042';
		System.out.println(c);
		System.out.println(d);
	}
}
