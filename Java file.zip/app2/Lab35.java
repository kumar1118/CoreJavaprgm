class Lab35 
{
	public static void main(String[] args) 
	{
		char ch1 = 'a';
		char ch2 = 'j';
		char ch3 = '5';
		char ch4 = '*';
		System.out.println(ch1);
		System.out.println(ch2);
		System.out.println(ch3);
		System.out.println(ch4);
	}
}
