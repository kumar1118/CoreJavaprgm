class Lab21
{
	public static void main(String[] args) 
	{
		int a= 99;
		System.out.println(a);
		a = 88;
		System.out.println(a);
	}
}
