class Lab70 
{
	pu\u0062li\u0063st\u0061ti\u0063 void m\u0061in(String args[])
	{
		int\u0041\u0042=123;
			System.out.println(AB);
	}
}
