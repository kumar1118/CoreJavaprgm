class Lab21 
{
	public static void main(String[] args) 
	{
		final int A = 99;
		System.out.println(A);
		A = 88;
		System.out.println(A);

	}
}
