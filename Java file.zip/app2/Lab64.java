class Lab64 
{
	public static void main(String[] args) 
	{
		int a = \u0037;
		int b = \u0037;
		System.out.println(a);
		System.out.println(b);
	}
}
