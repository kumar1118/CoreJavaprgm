class Lab32 
{
	public static void main(String[] args) 
	{
		boolean True = true;
		boolean b = True;
		System.out.println(b);
	}
}
