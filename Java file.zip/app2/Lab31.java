class Lab31 
{
	public static void main(String[] args) 
	{
		boolean b1 = true;
		boolean b2 = false;
		System.out.println(b1);
		System.out.println(b2);
	}
}
