class A 
{
	public static void main(String[] args) 
	{
		int i = 12;
		double j = 100.8;
		char k = 'r';
		boolean m = false;
		String n = "hello";
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(m);
		System.out.println(n);
	}
}
