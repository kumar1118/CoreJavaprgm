class Lab68 
{
	public static void main(String[] args) 
	{
		int a=99;
		int x = \u0061;
		System.out.println(x);
	}
}
