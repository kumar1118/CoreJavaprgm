class Lab12 
{
	public static void main(String[] args) 
	{
		String str1, str2, str3;
		str1 = str2 = str3 = "LT";
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
	}
}
