class Lab65 
{
	public static void main(String[] args) 
	{
		int a= '\u0037\u0039';
		System.out.println(a);
	}
}
