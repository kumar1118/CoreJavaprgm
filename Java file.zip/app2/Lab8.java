class Lab8
{
	static String Cname = "bf";
	 int Id;
	public static void main(String[] args) 
	{
		Lab8 l = new Lab8();
			System.out.println(Cname);
			System.out.println(l.Id);
	}
}
