class Lab14 
{
	public static void main(String[] args) 
	{
		int a = 120;
		int b = 76;
		int c = 56;

		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
}
