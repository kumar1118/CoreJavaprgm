class Lab67 
{
	public static void main(String[] args) 
	{
		int\u0061=99;
		System.out.println(a);
	}
}
