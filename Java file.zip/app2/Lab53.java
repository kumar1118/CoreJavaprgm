class Lab53 
{
	public static void main(String[] args) 
	{
		char ch1 = 360;
		char ch2 = '?';
		System.out.println(ch1);
		System.out.println(ch2);
	}
}
