class Lab5 
{
	static int a;
	public static void main(String[] args) 
	{
		System.out.println(a);
	}
}
