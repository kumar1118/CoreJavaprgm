class Lab62 
{
	public static void main(String[] args) 
	{
		char ch1 = '\u0061';
		char ch2 = '\u0062';
		System.out.println(ch1);
		System.out.println(ch2);
		char ch3 = '\u0041';
		char ch4 = '\u0042';
		System.out.println(ch3);
		System.out.println(ch4);

	}
}
