class Lab43 
{
	public static void main(String[] args) 
	{
		char ch = '\"';
		System.out.println(ch);
	}
}
