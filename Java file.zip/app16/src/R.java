class P
{
	P()
	{
		System.out.println("P()");
	}
	
	{
		System.out.println("P-IIB1");
		System.out.println("P-IIB2");
	}
}
class Q extends P
{
	Q()
	{
		System.out.println("Q()");
	}
	
	{
		System.out.println("Q-IIB1");
		System.out.println("Q-IIB2");
	}
}
class R
{
	public static void main(String[] args) 
	{
		Q q1 = new Q();
		System.out.println(".........");
		P p1 = new P();
	}
}
