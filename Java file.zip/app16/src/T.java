class T 
{
	{
		System.out.println("T-IIB1");
	}
	T()
	{
		System.out.println("T()");
	}

	{
		System.out.println("T-IIB2");
	}
}
class U extends T
{
	{
		System.out.println("U-IIB1");
	}
	U()
	{
		System.out.println("U()");
	}

	{
		System.out.println("U-IIB2");
	}
}
class V
{
	public static void main(String[] args) 
	{
		
		U u1 = new U();
		System.out.println(".........");
		T t1 = new T();
	}
}
