class  H
{
	static
	{
		System.out.println("H-SIB");
	}
	static void test1()
	{
		System.out.println("from H-test1");
	}
}
class  I extends H
{
	static
	{
		System.out.println("I-SIB");
	}
	static void test2()
	{
		System.out.println("from I-test2");
	}
}
class  J extends I
{
	static
	{
		System.out.println("J-SIB");
	}
	static void test3()
	{
		System.out.println("from J-test3");
	}
}
class K
{
	static
	{
		System.out.println("K-SIB");
	}
	public static void main(String[] args) 
	{
		System.out.println("K-main-begin");
		I.test2();
		System.out.println("..............");
		J.test3();
		System.out.println("..............");
		H.test1();
		System.out.println("..............");
		System.out.println("K-main-end");
	}
}
class L
{
	static
	{
		System.out.println("L-SIB");
	}
	public static void main(String[] args) 
	{
		System.out.println("L-main-begin");
		J.test3();
		System.out.println("..............");
		H.test1();
		System.out.println("..............");
		I.test2();
		System.out.println("..............");
		System.out.println("L-main-end");
	}
}

//output from K
K-SIB
K-main-begin
I-SIB
from I-test2
..............
J-SIB
from J-test3
..............
H-SIB
from H-test1
..............
K-main-end

//output from G
L-SIB
L-main-begin
J-SIB
from J-test3
..............
H-SIB
from H-test1
..............
I-SIB
from I-test2
..............
L-main-end

















