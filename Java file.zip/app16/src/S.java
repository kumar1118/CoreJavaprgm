class S 
{
	{
		System.out.println("S-IIB1");
		System.out.println("S-IIB2");
	}
	S()
	{
		System.out.println("S()");
	}

	{
		System.out.println("S-IIB-A");
		System.out.println("S-IIB-B");
	}
	public static void main(String[] args) 
	{
		S s1 = new S();
	}
}

//Output
//S-IIB1
//S-IIB2
//S-IIB-A
//S-II-B
//S()





