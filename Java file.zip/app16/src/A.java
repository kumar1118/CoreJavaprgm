class A 
{
	static
	{
		System.out.println("A-SIB");
	}
}
class B extends A
{
	static
	{
		System.out.println("B-SIB");
	}
}
class C extends B
{
	static
	{
		System.out.println("C-SIB");
	}
	public static void main(String[] args) 
	{
	
		System.out.println("from C.main");
	}
}

//A-SIB
//B-SIB
//C-SIB
//from C.main




