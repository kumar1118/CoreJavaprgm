class M 
{
	M()
	{
		System.out.println("M()");
	}
	
	{
		System.out.println("M-IIB");
	}
}
class N extends M
{
	N()
	{
		System.out.println("N()");
	}
	
	{
		System.out.println("N-IIB");
	}
}
class O
{
	public static void main(String[] args) 
	{
		M m1 = new M();
		
		System.out.println("..........");
		N n1 = new N();
	}
}
