class D
{
	static
	{
		System.out.println("D-SIB");
	}
	static int i;
}
class E extends D
{
	static
	{
		System.out.println("E-SIB");
	}
	static void test()
	{
		System.out.println("E-test");
	}
}
class F
{
	
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		System.out.println(D.i);
		System.out.println("...............");
		E.test();
		System.out.println("main end");
	}
}
class G 
{
	
	public static void main(String[] args) 
	{
		
		System.out.println("main begin");
		E.test();
		System.out.println(D.i);
		System.out.println("...............");
		System.out.println("main end");
	}
}





