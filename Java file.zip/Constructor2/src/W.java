class W
{
	int i;
	 W(int i)
	{
		this.i = i;
	}
	public static void main(String[] args) 
	{
		W w1 = new W(10);
		System.out.println(w1.i);
	}
}




//10

//This statement is calling to global variable
//'this.i' means global 'i'.
//