class V 
{
	int i;
	 V(int i)
	{
		 i = i;
	}
	public static void main(String[] args) 
	{
		V v1 = new V(10);
		System.out.println(v1.i);
	}
}

//0
//global i not refering inside the constructor
//local i is assigning to i
//if global and local have same name local will be prefered.
//