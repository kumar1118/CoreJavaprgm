class I 
{
	I()
	{
		System.out.println("I()");
	}
	
	{
		System.out.println("IIB");
	}
	public static void main(String[] args) 
	{
		I obj1 = new I();
		System.out.println("..........");
		I obj2 = new I();
		System.out.println("..........");
	}
}

//IIB
//I()
//......
//IIB
//I()
//......

/// iib class..instance initialization block
//IIB are executing while object is creating
//not only constructor
//difference is 