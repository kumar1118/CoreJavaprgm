class D 
{
	D()
	{
		this(10,20);
		System.out.println("D()");
	}
	D(int i)
	{
		System.out.println("D(int)");
	}
	D(int i, int j)
	{
		this(i);
		System.out.println("D(int,int)");
	}
	public static void main(String[] args) 
	{
		D d1 = new D(90);
		System.out.println("........");
		D d2 = new D(90,20);
		System.out.println("........");
		D d3 = new D();
		System.out.println("........");
	}
}


//D(int)
//........
//D(int)
//D(int,int)
//.....
//D(int)
//D(int,int)
//D(int)
//.......
