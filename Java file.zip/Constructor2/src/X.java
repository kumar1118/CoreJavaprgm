class X 
{
	int i;
	X(int j)
	{
		i = j;
	}
	public static void main(String[] args) 
	{
		X x1 = new X(10);
		System.out.println(x1.i);
	}
}

//10