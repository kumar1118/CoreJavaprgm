class A 
{
	A(int i)
	{
		System.out.println("A(int)");
	}
	A(int i, int j)
	{
		System.out.println("A(int,int)");
	}
	public static void main(String[] args) 
	{
		A a1 = new A()
		System.out.println("************");
		A a2 = new A(10);
		System.out.println("************");
		A a3 = new A(1,0);
		System.out.println("************");
	}
}
//Error
// becose of 