class L 
{
	L()
	{
		System.out.println("L()");
	}
	
	{
		System.out.println("L-IIB1");
	}
	{
		System.out.println("L-IIB2");
	}
	public static void main(String[] args) 
	{
		L obj1 = new L();
		System.out.println(".........");
		L obj2 = new L();
		System.out.println(".........");
	}
}

//Output
//L-IIB1
//L-IIB2
//L()
//........
//L-IIB1
//L-IIB2
//L()
//........