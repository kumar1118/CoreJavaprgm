class N 
{
	N()
	{
		this(90);
		System.out.println("N()");
	}
	
	{
		
		System.out.println("IIB");
	}
	N(int i)
	{
		
		System.out.println("N(int)");
	}
	public static void main(String[] args) 
	{
		N n1 = new N();
		System.out.println(".........");
		N n2 = new N(10);
		System.out.println(".........");
	}
}


//Output
//IIB 
//N(int)
//N()
//.........
//IIB
//N(int)
//........

//IIb execution is only one while 