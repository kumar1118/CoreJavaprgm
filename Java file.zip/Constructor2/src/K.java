class K 
{
	K()
	{
		System.out.println("K()");
	}
	K(int i)
	{
		System.out.println("K(int)");
	}
	K(int i,int j)
	{
		System.out.println("K(int,int)");
	}
	
	{
		System.out.println("IIB");
	}
	public static void main(String[] args) 
	{
		K obj1 = new K();
		System.out.println("........");
		K obj2 = new K(10);
		System.out.println("........");
		K obj3 = new K(10,20);
		System.out.println("........");
	}
}

//Output
//IIB
//K()
//.........
//IIB
//K(int)
//.........
//IIB
//K(int,int)
//.........