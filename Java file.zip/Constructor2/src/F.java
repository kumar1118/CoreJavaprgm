class F
{
	F()
	{
		System.out.println("F()");
		this(10);
	}
	F(int i)
	{
		System.out.println("F(int)");
	}
	
}


// compile time error