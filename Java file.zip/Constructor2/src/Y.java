class Y 
{
	static
	{
		System.out.println("Y-SIB");
	}
	Y()
	{
		System.out.println("Y()");
	}
}
class Z
	{
		public static void main(String[] args) 
	{
		System.out.println("main begin");
		Y y1 = new Y();
		System.out.println("..........");
		Y y2 = new Y();
		System.out.println("main end");
	}
}


//main begin
//Y-SIB
//Y()
//main end