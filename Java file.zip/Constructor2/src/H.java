class H 
{
	H()
	{
		this();
	}
}
