class M 
{
	M()
	{
		System.out.println("M()");
	}
	
	{
		System.out.println("M-IIB1");
	}
	M(int i)
	{
		System.out.println("M(int)");
	}
	
	{
		System.out.println("M-IIB2");
	}
	public static void main(String[] args) 
	{
		M m1 = new M(90);
		System.out.println("..........");
		M m2 = new M();
		
	}
}


//Output
//M-IIB1
//M-IIB2
//M(int)
//.......
//M-IIB1
//M-IIB2
//M()
