class T 
{
	static
	{
		System.out.println("T-SIB");
	}
	T()
	{
		System.out.println("T()");
	}
	T(int i)
	{
		System.out.println("T(int)");
	}
	{
		System.out.println("T-IIB)");
	}
	public static void main(String[] args) 
	{
		T t1 = new T();
		System.out.println("..........");
		T t2 = new T(10);
		System.out.println("..........");
	}
}

//T-SIB
//T-IIB
//T()
//..........
//T-IIB
//T(int)
//..........