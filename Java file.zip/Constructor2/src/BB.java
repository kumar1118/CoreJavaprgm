class BB 
{
	BB()
	{
		System.out.println("BB()");
	}
	static
	{
		System.out.println("B-SIB1");
	}
	{
		System.out.println("B-IIB1");
	}
	BB(int i)
	{
		this();
		System.out.println("BB(int)");
	}
	BB(int i, int j)
	{
		this(10);
		System.out.println("BB(int,int)");
	}
	static
	{
		System.out.println("B-SIB2");
	}
	{
		System.out.println("B-IIB2");
	}
	public static void main(String[] args) 
	{
		BB obj1 = new BB();
		System.out.println("............");
		BB obj2 = new BB(10);
		System.out.println("............");
		BB obj3 = new BB(10,20);
		System.out.println("............");
	}
}

//B-SIB1
//B-SIB2
//B-IIB1
//B-IIB2
//BB()
//............
//B-IIB1
//B-IIB2
//BB()
//BB(int)
//............
//B-IIB1
//B-IIB2
//BB()
//BB(int)
//BB(int,int)
//............
