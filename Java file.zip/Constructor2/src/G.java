class G 
{
	G(int i)
	{
		this();
		System.out.println("G(int)");
	}
	G()
	{
		this(10);
		System.out.println("G()");
	}
}
