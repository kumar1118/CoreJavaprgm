class U 
{
	static
	{
		System.out.println("U-SIB");
	}
	{
		System.out.println("U-IIB");
	}
	U()
	{
		System.out.println("U()");
	}
	U(int i)
	{
		this();
		System.out.println("U(int)");
	}

	public static void main(String[] args) 
	{
		System.out.println("main begin");
		U u1 = new U();
		System.out.println("...........");
		U u2 = new U(20);
		System.out.println("...........");
	}
}

//U-SIB
//main begin
//U-IIB
//U()
//.......
//U-IIB
//U()
//U(int)
//.......