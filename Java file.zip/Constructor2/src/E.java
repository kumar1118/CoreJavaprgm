class E 
{
	E(int i)
	{
		this();
		System.out.println("E(int)");
	}
	E()
	{
		this(10,20);
		System.out.println("E()");
	}
	E(int i, int j)
	{
		
		System.out.println("E(int,int)");
	}
	public static void main(String[] args) 
	{
		E e1 = new E();
		System.out.println(".........");
		E e2 = new E(10,20);
		System.out.println(".........");
		E e3 = new E(10);
		System.out.println(".........");
	}
}

//E(int,int)
//E()
//.........
//E(int,int)
//.........
//E(int,int)
//E()
//E(int)
//.........