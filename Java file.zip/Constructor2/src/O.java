class O 
{
	O()
	{
		System.out.println("O()");	
	}
	
	{
		System.out.println("O-IIB1");	
	}
	O(int i)
	{
		this();
		System.out.println("O(int)");	
	}
	
	{
		
		System.out.println("O-IIB2");	
	}
	public static void main(String[] args) 
	{
		O o1 = new O();
		System.out.println(".......");
		O o2 = new O(90);
		System.out.println(".......");
	}
}


//Output


//O-IIB1
//O-IIB2
//O()
//.....
//O-IIB1
//O-IIB2
//O()
//O(int)
//.....
