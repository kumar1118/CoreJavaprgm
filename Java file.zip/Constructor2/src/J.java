class J 
{
	J()
	{
		System.out.println("J()");
	}

	{
		System.out.println("IIB");
	}
	J(int x)
	{
		System.out.println("J(int)");
	}
	public static void main(String[] args) 
	{
		J obj1 = new J();
		System.out.println("..........");
		J obj2 = new J(90);
		//System.out.println("..........");
	}
}
//output
//IIB
//J()
//.........
//IIB
//J(int)