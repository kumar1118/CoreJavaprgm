class O 
{
	int i;
	static void test() 
	{

		O o1 = new O();
		System.out.println(o1.i);
	}
}
// main method is not found.
//so run time error