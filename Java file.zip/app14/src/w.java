class W 
{
	int i;
	static void test1(W obj)
	{
		System.out.println("test1 main:"+obj.i);
		obj.i = 2;
		test2(obj);
		System.out.println("test1 end:"+obj.i);
	}
	static void test2(W w1)
	{
		System.out.println("test2:"+w1.i);
		w1.i = 3;
		
	}
	public static void main(String[] args) 
	{
		W ref = new W();
		ref.i = 4;
		test1(ref);
		System.out.println("main1:"+ref.i);
		ref.i = 5;
		test2(ref);
		System.out.println("main2:"+ref.i);
	}
}

//test1 main:4
//test2:2
//test1 end:3
//main1:3
//test2:5
//main2:3