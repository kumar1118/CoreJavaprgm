class X 
{
	int i;
	static void test1()
	{
		X x1 = new X();
		x1.i = 10;
		System.out.println("test1:"+x1.i);
	}
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		test1();
		System.out.println("main end");

	}
}
//main begin
//test1:10
//main end