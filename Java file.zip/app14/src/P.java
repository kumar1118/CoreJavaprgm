class P 
{
	void test1()
	{
	}
	static void test2()
	{
		P p1 = new P();
		p1.test1();
	
	}
}
//main method not found
//run time Error