class J 
{
	int x;
	public static void main(String[] args) 
	{
		J j1 = new J();
		System.out.println(j1.x);
		j1.x = 20;
		System.out.println(j1.x);
	}
}
//0
//20