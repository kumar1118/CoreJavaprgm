class E 
{
	int i;
	static
	 
	{
		System.out.println(i);
	}
}
// compile time Error
//non static variable i cannot be referenced from a static context