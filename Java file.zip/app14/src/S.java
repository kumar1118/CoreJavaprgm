class S 
{
	int i;
	public static void main(String[] args) 
	{
		S s1 = new S();
		s1.i = 10;
		S s2 = s1;
		s2.i = 20;
		System.out.println(s1.i);
		System.out.println(s2.i);
	}
}
//20
//20