class C 
{
	int i;
	static void test1()
	{
		i = 10;
	}
}
// compile time Error
//non static variable i cannot be referenced from a static context