class Z 
{
	int i;
	static Z test1()
	{
	System.out.println("test1 begin");
	Z z1 = test2();
	System.out.println("test1 end:"+z1.i);
	z1.i = 10;
	return z1;
	}
	static Z test2()
	{
		System.out.println("test2 begin");
	Z obj = new Z();
	obj.i = 15;
	System.out.println("test2 end:"+obj.i);
	return obj;
	}
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		Z obj1 = test1();
		System.out.println("main end:"+ obj1.i);
	}
}


//main begin
//test1 begin
//test2 begin
//test2 end:15
//test1 end:15
//main end:10