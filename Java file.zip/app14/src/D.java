class D 
{
	void test1()
	{
	}
	static void test2() 
	{
		test1();
	}
}
// compile time Error
//non static method cannot be referenced from a static context