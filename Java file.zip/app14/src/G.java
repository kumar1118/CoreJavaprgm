class G 
{
	int i;
	
	static
	{
		i = 30;
	}
}
// compile time Error
//non static variable i cannot be referenced from a static context