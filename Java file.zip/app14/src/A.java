class A 
{
	int i;
	public static void main(String[] args) 
	{
		System.out.println(i);
	}
}
// error