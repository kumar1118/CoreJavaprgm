class V 
{
	int i;
	static void test1(V v1)
	{
		System.out.println("from test1:" +v1.i);
		v1.i = 10;
	}
	static void test2(V v1)
	{
		System.out.println("from test2:" +v1.i);
		v1.i = 20;
	}
	public static void main(String[] args) 
	{
		V v1 = new V();
		v1.i = 30;
		test1(v1);
		System.out.println("from main1:" + v1.i);
		v1.i = 40;
		test2(v1);
		System.out.println("from main2:" + v1.i);
	}
}

//from test1:30
//from main1:10
//from test2:40
//from main2:20

//