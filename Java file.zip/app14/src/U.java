class U 
{
	int i;
	static void test(U u1)
	{
		System.out.println("from test:" +u1.i);
		u1.i = 20;
	}
	public static void main(String[] args) 
	{
		U obj = new U();
		obj.i = 10;
		test(obj);
		System.out.println("from main:" +obj.i);
	}
}

//from test:10
//from main :20