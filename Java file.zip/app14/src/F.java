class F 
{

	void test1()  
	{
	}
	static
	{
		test1();
	}
}
// compile time Error
//non static method cannot be referenced from a static context