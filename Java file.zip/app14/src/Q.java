class Q 
{
	int i;

	static
	{
		Q q1 = new Q();
	
		System.out.println(q1.i);
	}
}
////main method not found
//run time error