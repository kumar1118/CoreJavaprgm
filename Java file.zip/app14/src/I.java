class I 
{
	int x;
	public static void main(String[] args) 
	{
		I ref = new I();
		System.out.println(ref.x);
	}
}
// 0