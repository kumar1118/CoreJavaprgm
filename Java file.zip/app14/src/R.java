class R 
{
	void test1()
	{
	}
	static
	{
		R r1 = new R();
		r1.test1();
	
	}
}
//main method not found
//run time error