class K 
{
	int y;
}
class L
{
	public static void main(String[] args) 
	{
		K k1 = new K();
		System.out.println(k1.y);
	}
}
