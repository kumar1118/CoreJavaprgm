class T 
{
	int i;
	public static void main(String[] args) 
	{
		T t1 = new T();
		T t2 = t1;
		T t3 = t2;
		System.out.println(t1.i);
		System.out.println(t2.i);
		System.out.println(t3.i);
		t1.i = 1;
		t2.i = 2;
		t3.i = 3;
		System.out.println(t1.i);
		System.out.println(t2.i);
		System.out.println(t3.i);
	}
}
//0
//0
//0
//3
//3
//3
