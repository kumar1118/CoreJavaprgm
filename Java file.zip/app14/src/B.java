class B 
{
	void test1()
	{
	}
	public static void main(String[] args) 
	{
	test1();
	}
}
// compile time Error
//non static method cannot be referenced from a static context