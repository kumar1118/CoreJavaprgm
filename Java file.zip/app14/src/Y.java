class Y 
{
	int i;
	static Y test1()
	{
		Y y1 = new Y();
		y1.i = 10;
		System.out.println("from test1:"+y1.i);
		return y1;
	}
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		Y obj = test1();
		System.out.println("main end:"+obj.i);
	}
}


//main begin
//from test:10
//main end:10