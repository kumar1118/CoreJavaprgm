class  N
{
	int i;
	void test1()
	{
		System.out.println("from test1");
	}
	public static void main(String[] args) 
	{
		N n1 = new N();
		n1.i = 10;
		System.out.println("...............");
		System.out.println(n1.i);
		n1.test1();
	}
}
//.........
//10
//from test1
