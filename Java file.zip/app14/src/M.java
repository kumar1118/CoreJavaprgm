class M 
{
	void test1()
	{
		System.out.println("from test1");
	}
	public static void main(String[] args) 
	{
		M m1 = new M();
		m1.test1();
		System.out.println("done");
	}
}


//from test1
//done