class S
{
	S(int i, int i)
	{
		System.out.println("S(int, int)");
	}
	S(int i, double j)
	{
		System.out.println("S(int, double)");
	}
	public static void main(String[] args) 
	{
		S s1 = new S(10,20.8);
		System.out.println(".........");
		S s1 = new S(5,8);
	}
}
