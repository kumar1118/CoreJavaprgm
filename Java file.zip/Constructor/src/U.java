class U 
{
	U(int i)
	{
		System.out.println("U(int i)");
	}
	public static void main(String[] args) 
	{
		U obj = new U();
		System.out.println("Hello World!");
	}
}
//Compile time Error
//Becose of object cannot find no argument constructor.