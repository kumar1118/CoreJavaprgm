class E 
{
	int i;
	static void test1(E e1, E e2)
	{
		System.out.println("from test1:"+e1.i);
		System.out.println("from test1:"+e2.i);
		e1.i = 10;
		e2.i = 20;
	}
	public static void main(String[] args) 
	{
		E obj1 = new E();
		E obj2 = new E();
		obj1.i = 30;
		obj2.i = 40;
		test1(obj1, obj2);
		System.out.println("from main:"+obj1.i);
		System.out.println("from main:"+obj2.i);
	}
}
//from test1:30
//from test1:40
//from main:10
//from main:20