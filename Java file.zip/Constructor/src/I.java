class I
{
	int x;
	void test1()
	{
		System.out.println("from test1:"+this.x);
		this.x = 10;
	}
	public static void main(String[] args) 
	{
		I obj1 = new I();
		obj1.x = 5;				// this is nothing but i1.
		obj1.test1();
		System.out.println("from main1:"+obj1.x);
		
	}
}
//from test1:5
//from main1:10