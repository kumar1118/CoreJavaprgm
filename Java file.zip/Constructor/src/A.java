class A 
{
	int i;
	public static void main(String[] args) 
	{
		A a1 = new A();
		A a2 = new A();
		System.out.println(a1.i);
		System.out.println(a2.i);
	}
}
//0
//0