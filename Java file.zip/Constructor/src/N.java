//Constructor

class N
{
	int i;
	N()
	{
		i = 10;
	}
	public static void main(String[] args) 
	{
		N n1 = new N();
		System.out.println(n1.i);
		
	}
}
//10