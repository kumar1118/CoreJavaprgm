class F 
{
	void test()
	{
		System.out.println("from tes:"+this);
	}

	public static void main(String[] args) 
	{ 
		F f1 = new F();
		System.out.println("from main:"+f1);
		f1.test();
	}
}
