class  M4
{
	public static void main(String[] args) 
	{
		boolean[] = new boolean[7];
		for(boolean flag : x)
		{
		System.out.println(flag + ",");
	}
	System.out.println();
	System.out.println("...........");
}
