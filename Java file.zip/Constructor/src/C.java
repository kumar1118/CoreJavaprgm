class  C
{
	int i;
	public static void main(String[] args) 
	{
		C c1 = new C();
		C c2 = new C();
		C c3 = new C();
		c1.i = 15;
		c2.i = 25;
		c3.i = 35;
		System.out.println(c1.i);
		System.out.println(c2.i);
		System.out.println(c3.i);
	}
}
//15
//25
//35