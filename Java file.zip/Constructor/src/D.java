class D 
{
	int i;
	static void test1(D obj1, D obj2)
	{
		System.out.println("from test1:"+obj1.i);
		System.out.println("from test1:"+obj2.i);
	}
	public static void main(String[] args) 
	{
		D d1 = new D();
		d1.i = 20;
		D d2 = new D();
		d2.i = 30;
		test1(d1,d2);
		System.out.println("end");
	}
}
//from test1:20
//from test2:20
//end