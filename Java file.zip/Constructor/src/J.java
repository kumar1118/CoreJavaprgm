class J
{
	int x;
	void test1()
	{
		System.out.println("from test1:"+ x);
		x = 20;
	}
	public static void main(String[] args) 
	{
		J obj = new J();
		obj.x = 10;
		obj.test1();
		System.out.println("from main1:"+obj.x);
		
	}
}
//from test1:10
//from main1:20