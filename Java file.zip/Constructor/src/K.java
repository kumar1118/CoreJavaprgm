class K 
{
	int i;
	void test1()
	{
		System.out.println("from test1:"+i);
		i = 10;
		test2();
	}
	void test2()
	{
		System.out.println("from test2:"+i);
		i = 20;
	}
	public static void main(String[] args) 
	{
		K k1 = new K();
		k1.i = 30;
		k1.test2();
		System.out.println("from main1:"+k1.i);
		k1.i = 40;
		k1.test1();
		System.out.println("from main2:"+k1.i);
	}
}
//from test2:30
//from test2:30