class G
{
	void test1()
	{
		System.out.println("from test1:"+this);
	}
	void test2()
	{
		System.out.println("from test2:"+this);
	}

	public static void main(String[] args) 
	{ 
		G g1 = new G();
		System.out.println("from main:"+g1);
		g1.test1();
		g1.test2();
	}
}
//from main:
//from test1:
//from test2: