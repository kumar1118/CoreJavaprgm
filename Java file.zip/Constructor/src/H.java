class H 
{
	void test1()
	{
		System.out.println("from test1:"+this);
	}
	public static void main(String[] args) 
	{
		H h1 = new H();
		H h2 = new H();
		System.out.println("from main:"+h1);
		System.out.println("from main:"+h2);
		h1.test1();
		h2.test1();
	}
}
