class P 
{
	P()
	{
		System.out.println("P()");
	}
	P(int i)
	{
		System.out.println("P(int i)");
	}
	public static void main(String[] args) 
	{
		P p1 = new P();
		System.out.println(".........");
		P p2 = new P(10);
		System.out.println(".........");
	}
}
