class W 
{
	public static void main(String[] args) 
	{
		W w1 = new W(90);
		System.out.println("Hello World!"); 
	}
}


// compile time Error 
// becose of if there is no constructor in the class the only no argument constructor is by default uses.