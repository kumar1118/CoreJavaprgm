class O 
{
	int i,j;
	O()
	{
		i = 10;
		j = 20;
	}
	public static void main(String[] args) 
	{
		O o1 = new O();
		System.out.println(o1.i);
		System.out.println(o1.j);
	}
}
//10
//20