class T 
{
	T(int i)
	{
		System.out.println("T(int i)");
	}
	T(int j)
	{
		System.out.println("T(int j)");
	}
	
}


//compile time Error
//becose of method have same arguments