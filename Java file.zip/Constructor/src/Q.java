class Q 
{
	Q(int i)
	{
		System.out.println("Q(int)");
	}
	Q(int i, int j)
	{
		System.out.println("Q(int, int)");
	}
	public static void main(String[] args) 
	{
		Q q1 = new Q(10,20);
		System.out.println(".........");
		Q q2 = neww Q(10);
	}
}
//Q(int, int)
//........
//Q(int)