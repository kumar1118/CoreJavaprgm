class V 
{
	public static void main(String[] args) 
	{
		V v1 = new V();
		System.out.println("Hello World!");
	}
} 


// hello world!
// default constructor is uses.