class R
{
	r(int i)
	{
		System.out.println("R(int)");
	}
	R(double i)
	{
		System.out.println("R(double)");
	}
	public static void main(String[] args) 
	{
		R r1 = new R(9);
		System.out.println(".........");
		R r2 = new R(9.8);
	}
}
//R(int)
//........
//R(double)