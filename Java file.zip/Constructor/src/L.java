//Constructor

class L 
{
	L()
	{
		System.out.println("L()");
	}
	public static void main(String[] args) 
	{
		L obj1 = new L();
		System.out.println("...............");
		L obj2 = new L();
	}
}
