//Constructor

class M
{
	M()
	{
		System.out.println("M()");
	}
	public static void main(String[] args) 
	{
		M m1 = new M();
		System.out.println("...............");
		M m2 = new M();
		System.out.println("...............");
		M m3 = new M();
		System.out.println("...............");
		
	}
}
