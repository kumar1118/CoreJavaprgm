class  H
{
	static int x;
	public static void main(String[] args) 
	{
		System.out.println(x);
		int x = 20;
		System.out.println(x);
	}
}
