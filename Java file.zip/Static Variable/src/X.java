class X 
{
	static int i = test();
	static int test()
	{
		return 10;
	}
	public static void main(String[] args) 
	{
		System.out.println(i);
	}
}
// it containing one global varible and two methods.
//method is data type and return 10
//any method can be used if assignment is properly or not?
//