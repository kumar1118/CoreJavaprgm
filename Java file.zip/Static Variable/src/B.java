class  B
{
	static int i;
	static int j;
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
	}
}
