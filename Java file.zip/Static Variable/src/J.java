class J 
{
	public static void main(String[] args) 
	{
		int x = 20;
		double x = 20.9;
	}
}
