class Z 
{
	static int i = test1();
	static int test1()
	{
		System.out.println("from test1");
		return 20;
	}
	public static void main(String[] args) 
	{
		System.out.println("from main");
		System.out.println(i);
		System.out.println("main end");
	}
}
// loading operation is working'
//first print 
//from test1//
//from main//
//20//
//main end//
//two stwps of operation
//storing every static member in memory
//executing initializer from top to bottom
//non static memory not loading
//static member are only class member
//all static member have default value.
//