class N 
{
	static int x;
	public static void main(String[] args) 
	{
		int x = 20;
		System.out.println(x);
		System.out.println(N.x);
		x = 30;
		N.x = 40;
		System.out.println(x);
		System.out.println(N.x);
	}
}
//global variable is a only member of class
// N.x = .x is a dot operator