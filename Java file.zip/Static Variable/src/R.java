class R 
{
	static int i = 10;
	static int j = i;
	static int k = i;
	static int m = j;
	static int n = j;
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(m);
		System.out.println(n);
	}
}
//output
//10
//10
//10
//10
//10