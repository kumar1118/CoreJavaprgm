class T
{
	static int i = 1;
	static int j = i;
	static int k = i + j;
	
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		
	}
}
//output
//1
//1
//2