class  D
{
	static int i;
	public static void main(String[] args) 
	{
		System.out.println(i);
		i = 10;
		System.out.println(i);
		}
}
