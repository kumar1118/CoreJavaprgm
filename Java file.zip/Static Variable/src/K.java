class K 
{
	static int x = 100;
	static double x = 39.89;
	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}
// compile time error due to variable x is same//