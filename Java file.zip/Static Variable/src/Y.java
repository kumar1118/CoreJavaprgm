class Y 
{
	static int i = test1();
	static int test1()
	{
		return 10;
	}
	static int j = test1();
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
	}
}
