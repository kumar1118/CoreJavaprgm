class U
{
	static int i;
	static int j = i;
	static int k;
	static int m = i + j + k;
	
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(m);
		
	}
}
//output
//0
//0
//0
//0
// we can use any global variable as a initializer and getting default value is zero.