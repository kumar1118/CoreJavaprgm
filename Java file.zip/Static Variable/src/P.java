class P 
{
	static int x;
	public static void main(String[] args) 
	{
		System.out.println(P.x);
		P.x = 30;
		System.out.println(P.x);
	}
}
