class L 
{
	public static void main(String[] args) 
	{
		int x = 20;
		System.out.println("main1:" +x);
		x = 30;
		test1();
		System.out.println("main2:" +x);
	}
	public static void test1) 
	{
		int x = 100;
		System.out.println("test1:" +x);
		x = 200;
	}
}
// main1:20
//test1:100
//main2:30