class W 
{
	static int i;
	static int j = k;
	static int k = 1;
	
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
	}
}
//compile time error
// becose 'k' is not declare 
// so cant be use as a initializer
//