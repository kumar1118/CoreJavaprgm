class V 
{
	static int i = j;
	static int j;
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
	}
}
//compile time error 
// illegal forword referance.
//  global variable is not using without declare