class  I
{
	static int x;
	public static void main(String[] args) 
	{
		System.out.println(x);
		x = 10;
		System.out.println(x);
		int x = 20;
		System.out.println(x);
		x = 30;
		System.out.println(x);
		test();
	}
		public static void test()
	{
	System.out.println(x);
	}
}
