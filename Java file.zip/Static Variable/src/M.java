class M 
{
	public static void main(String[] args) 
	{
		int x = 10;
		System.out.println("main1:" +x);
		test1();
	}
	public static void test1()
	{
		System.out.println("test1:" +x);
	}
}
//compile time error due there is no global variable declare in the class.