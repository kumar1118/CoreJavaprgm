import java.util.Scanner;
class Q23
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number of rows");
		int rows = sc.nextInt();
		for(int i = 1; i <= rows; i++)
		{
			for(int j = 1; j <= rows; j++)
			{
					System.out.print(9);
			}
		System.out.println();
		}
	}
}
