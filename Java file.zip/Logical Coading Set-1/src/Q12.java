class Q12 
{
	public static void main(String[] args) 
	{
		for(char ch1 = 'a', ch2 = '0'; ch1 <= 'z'; ch1++)
		{
		System.out.println(ch1 + "" + ch2 + ",");
		if(ch2 == '9')
		{
			ch2 = '0';
		}
		else
		{
			ch2++;
		}
	}
}
}