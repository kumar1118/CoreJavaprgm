class Q7 
{
	public static void main(String[] args) 
	{
		for (char ch = 'z'; ch>='a' ; ch--)
		{
		System.out.print(ch+",");
		}
	}
}
