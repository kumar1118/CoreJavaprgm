class Q9 
{
	public static void main(String[] args) 
	{
		for (char ch = 'Z'; ch>='A' ; ch--)
		{
		System.out.print(ch+",");
		}
	}
}
