import java.util.Scanner;
class Q25
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number of rows");
		int rows = sc.nextInt();
		System.out.println("enter number of cols");
		int cols = sc.nextInt();
		//String s1 = sc.next();
		//char c1 = s1.charAt(0);
		for(int i = 1; i <= rows; i++)
		{
			for(int j = 1; j <= cols; j++)
			{
					System.out.print(9);
			}
		System.out.println();
		}
	}
}
