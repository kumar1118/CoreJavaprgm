abstract class V 
{
	V()
	{
		System.out.println("V()");
	}
		abstract void test1();
}
//compile successfully
//min 