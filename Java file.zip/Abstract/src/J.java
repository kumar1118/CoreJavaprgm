abstract class J
{
	abstract void test1();
}  
class K extends J
{
	void test1()
	{
		System.out.println("from test1");
}

	public static void main(String[] args) 
	{
		K k1 = new K();
		k1.test1();
		System.out.println("done");
	}
}
