abstract class B 
{
	abstract void test1()
	{
	}
}
//cte
//method should not having body