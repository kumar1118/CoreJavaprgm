class D
{
	abstract void test1();
}  
//if class declare as abstract
//when we usese the abstract method in the class then we must use a abstract class.
	