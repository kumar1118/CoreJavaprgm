abstract class P 
{
	abstract void test1();
	abstract void test2();
}
abstract class Q extends P
{
	void test1()

	{
		System.out.println("from test1");
	}
}
//bcoz q declare as abstract comiple succee 