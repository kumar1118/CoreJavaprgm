abstract class E
{
	void test1()

{
	
	System.out.println("Hello World!");
}
	abstract void test2();
	abstract void test3();
	abstract void test4();
}
//any no abstract class

//copile succefully