abstract class N
{
	abstract void test1();
	abstract void test2();
}  
class O extends N
{
void test1()
	{
		System.out.println("from test1");
	}
}
//cte
//o not declare as absrtract //

//