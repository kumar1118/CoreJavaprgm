abstract class W
{
	W()
	{
		System.out.println("W()");
	}  
	abstract void test1();
 }
class X extends W
{
	X()
	{
		System.out.println("X()");
	}
void test1()
	
	{
		System.out.println("from test1");

	}
	public static void main(String[]args)
	{
		X x1 = new X();
		System.out.println(".......");
		x1.test1();
}
}
//W()
//X()
//.....
//from test1