abstract class C
{
	void test1();
}  
//cte
//ending with semi colmn abstract keyword