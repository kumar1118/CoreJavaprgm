abstract class U
{
	void test1()
	{
	}  
	void test2()
	{
    }  
	void test3()
	{
    }  
}
//any class declare as absract class no matter abstract method are there or not 
//even class containuing min abstraact method it should declare as abstract //

//compile sucess