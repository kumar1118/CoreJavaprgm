abstract class L
{
	void test1()
	{
		System.out.println("from test1");
}  
abstract void test2();
}
class  M extends L
{
	void test2()
	{
System.out.println("from test2");
}

	public static void main(String[] args) 
	{
		M m1 = new M();
		m1.test1();
		m1.test2();
		System.out.println("done");
	}
}
//abstract method implement should im
//