abstract class A
{
	void test1()
	{
	}
	abstract void test2();
}
//test 1 having body ,define ,
//test 1 not having body ,no implementation so its declare  as abstract