abstract class F 
{
	abstract void test1();
	abstract int test2();
	 void test3()
	{
	}
}
class G
{
	public static void main (String[]args)
	{
		F f1 = new F();
		System.out.println("done");
	}
}


//can't create object of abstract class directly.