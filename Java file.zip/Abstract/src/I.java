abstract class H
{
	abstract void test1();
}
class I
{
	H h1;
	void mettod1(H h1)
	{
	}
	H method2()
	{
		return null;
	}
	public static void main (String[]args)
	{
		H h1 = null;
		System.out.println("done");
	}
}
//data type purpose
//compile run success
//done