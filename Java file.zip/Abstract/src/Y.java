abstract class Y 
{
	abstract void test1();
	abstract void test2();
	abstract void test3();
	abstract void test4();

}
//y/abstract  class containg atlest one constructor
//costructor r nt inherete in sub class 
//no class 100% abstract bcoz of conterete constructor r there