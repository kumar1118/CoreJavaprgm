interface H
{
	void test1();
}
class I implements H
{
	public void test1()
	{
		System.out.println("from test1");
	}

	public static void main(String[] args) 
	{
		H obj1 = null;
		I obj3 = new I();
		obj3.test1();
		System.out.println("done");
	}
}

//from test1
//done
//interfaces are derived data type
//all the abstract method , we can implementing.
















