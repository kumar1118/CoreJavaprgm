public interface C
{
	public void test1();
	public abstract void test();
	abstract void test3();
	void test4();
}