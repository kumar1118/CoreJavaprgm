interface D
{
	protected void test1();
	void test2();
}
//we cannot choose private and protected.
//becose interface member is public by default.
//public keywor only allowed 