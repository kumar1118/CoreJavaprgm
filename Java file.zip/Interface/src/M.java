interface L
{
	void test1();
	void test2();
	void test3();
}

abstract class  M implements L
{
	public void test1()
	{
	}
	public void test2()
	{
	}
}

//compile successfully
