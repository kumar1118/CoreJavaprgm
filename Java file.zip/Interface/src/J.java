interface J
{
	void test1();
	void test2();
	void test3();
}

class  K extends J
{
	public void test1()
	{
	}
	public void test2()
	{
	}
}


///cte
//becose of interface extends here
//interface cant extends only implements
//test3 is not implemented.