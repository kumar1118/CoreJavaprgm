interface E
{
	void test()
	{
	}

	E()
	{
	}

	{
	}

	static
	{
	}
}

//no constructor, no IIB, No SIB are allowed in the interface.
//constant and abstract method allowed.