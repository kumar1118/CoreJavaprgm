interface A
{
	void test1();
	void test2();
}

class  B
{
	public void test1()
	{
		System.out.println("from test1");
	}
}
class Z1 extends B implements A
{
	public void test2()
	{
		System.out.println("from test2");
	}
	public static void main(String[] args) 
	{
		Z1 obj = new Z1();
		obj.test1();
		obj.test2();
		System.out.println("done");
	}
}
//from test1
//from test2
//done





