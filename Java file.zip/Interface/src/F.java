interface F
{
	void test1();
}

class G implements F
{
	public void test1()
	{
	}
}

//while making a another class use implements only not extends.
//while you implementing the interface inside the a class you have to use public.