interface B
{
	void test1();
	void test2();
	void test3();
}

//inside a interface every method of a abstract is interface.
//bydefault interface is not a public but every member of interface is public.