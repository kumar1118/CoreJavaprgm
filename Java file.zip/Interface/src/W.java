interface U
{
	void test1();
}

abstract class V
{
	abstract void test2();
	void test3()
	{
	System.out.println("from test3");
	}
}
class W extends V implements U
{
	public void test1()
	{
		System.out.println("from test1");
	}
	void test2()
	{
		System.out.println("from test2");
	}
	public static void main(String[] args) 
	{
		W obj1 = new W();
		obj1.test1();
		obj1.test2();
		obj1.test3();
		System.out.println("done");
	}
}


//from test1
//from test2
//from test3
//done