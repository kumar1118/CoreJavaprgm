interface X
{
	void test1();
}
class  Y
{
	public void test1()
	{
		System.out.println("from test1");
	}
}
class Z extends Y implements X
{
	public static void main(String[] args) 
	{
		Z z1 = new Z();
		z1.test1();
		System.out.println("done");
	}
}
//from test1
//done
