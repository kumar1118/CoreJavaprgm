interface R
{
	void test1();
}

class S 
{
	void test2()
	{
		System.out.println("from test2");
	}
}
class T extends S implements R
{
	public void test1()
	{
		System.out.println("from test1");
	}
	public static void main(String[] args) 
	{
		T t1 = new T();
		t1.test1();
		t1.test2();
		System.out.println("done");
	}
}

//from test1
//from test2
//done













