interface A
{
}
