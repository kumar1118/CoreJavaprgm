interface O
{
	void test1();
	void test2();
}

abstract class  P implements O
{
	public void test1()
	{
		System.out.println("from test1");
	}
}
class Q extends P
{
	public void test2()
	{
		System.out.println("from test2");
	}
	public static void main(String[] args) 
	{
		Q q1 = new Q();
		q1.test1();
		q1.test2();
		System.out.println("Hello World!");
	}
}

//*from test1
//*from test2
//*Hello World!