class G 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if (args.length==0)
		{
		System.out.println("pls supply one int type CLA");
		return;
		}
		String s1 = args[0];
		int i = Integer.parseInt(s1);
		int j = i*i;
		System.out.println("i =" + i +" , j ="+j);
		System.out.println("main end");
		
	}
}

//main begin
//pls supply one int type CLA