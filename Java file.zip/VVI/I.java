class I
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if (args.length==0)
		{
		System.out.println("pls supply one boolean type CLA");
		return;
		}
		String s1 = args[0];
		boolean i = Boolean.parseBoolean(s1);
		boolean j = !i;
		System.out.println("i =" + i + " , j ="+j);
		System.out.println("main end");
	}
}

//main begin
//pls supply one boolean type CLA