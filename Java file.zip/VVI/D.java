class  D
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		for (int i = 0; i<args.length ;i++ )
		{
		System.out.println(args[i]);
		}
		System.out.println("main end");
	}
}
