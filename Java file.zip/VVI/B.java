class B 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		System.out.println(args.length);
		System.out.println("main end");
	}
}
