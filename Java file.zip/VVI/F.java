class  F
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(args.length==0)
		{
		System.out.println("pls supply command line args");
		System.out.println("like==>");
		System.out.println("app8>java F 45");
		return;
		}
		System.out.println(args[0]);
		System.out.println("main end");

	}
}

//main begin
//pls supply command line args
//like==>
//pp8>java F 45