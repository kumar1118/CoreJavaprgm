import java.util.Scanner;
class  K
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter string content");
		String s1 = sc.next();
		System.out.println("you have entered:" +s1);
		System.out.println("main end");
	}
}
// compile and print hello//
//main begin
//enter string content
//hello
//you have entered: hello
//main end