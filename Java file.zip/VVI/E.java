class E 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if (args.length==0)
		{
			System.out.println("pls supply one command line arg");
			return;
		}
		System.out.println(args[0]);
		System.out.println("main end");
		}
}
