import java.util.Scanner;
class  M
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter boolean type");
		boolean s1 = sc.nextBoolean();
		System.out.println("you have entered:" +s1);
		System.out.println("main end");
	}
}
// compile & run and write boolean like true then enter//
//main begin
//enter boolean type
//true
//you have entered: true
//main end