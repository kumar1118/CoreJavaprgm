class H
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if (args.length==0)
		{
		System.out.println("pls supply one double type CLA");
		return;
		}
		String s1 = args[0];
		double i = Double.parseDouble(s1);
		double j = i*i;
		System.out.println("i =" + i + " , j ="+j);
		System.out.println("main end");
	}
}
//main begin
//pls supply one double type CLA