import java.util.Scanner;
class  N
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter double type");
		double s1 = sc.nextDouble();
		System.out.println("you have entered:" +s1);
		System.out.println("main end");
	}
}
// compile & run then write double like 234.456 then enter//
//main begin
//enter double type
//9.8
//you have entered: 9.8
//main end