import java.util.Scanner;
class  L
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter int type");
		int s1 = sc.nextInt();
		System.out.println("you have entered:" +s1);
		System.out.println("main end");
	}
}
// compile and print hello//
//main begin
//enter int type
//45
//you have entered:45
//main end