class J
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if (args.length==0)
		{
		System.out.println("pls supply one char type CLA");
		return;
		}
		String s1 = args[0];
		char i = s1.charAt(0);
		char j = (char)(i + 1);
		System.out.println("i =" + i + " , j ="+j);
		System.out.println("main end");
	}
}
//main begin
//pls supply one boolean type CLA