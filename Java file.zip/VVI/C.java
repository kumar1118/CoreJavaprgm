class C 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println("main end");
	}
}
