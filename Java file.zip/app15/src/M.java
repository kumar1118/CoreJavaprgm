class M 
{
	int x;
}
class N
{
	M m1;
	String s1;
	int y;
	public static void main(String[] args) 
	{
		N n1 = new N();
		n1.m1 = new M();
		n1.s1 = new String();
		System.out.println(n1.m1.x);
		System.out.println(n1.s1.length());
		System.out.println(n1.y);
	}
}
//0
//0
//0