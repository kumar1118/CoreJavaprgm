class D 
{
	static int counter;
	D()
	{
		System.out.println("D()");
	}
	D(int i)
	{
		System.out.println("D(int)");
	}
	{
		counter++;
	}
	public static void main(String[] args) 
	{
		D d1 = new D();
		System.out.println(".........");
		D d2 = new D(10);
		System.out.println(".........");
		D d3 = new D();
		System.out.println(".........");
		D d4 = new D(20);
		System.out.println(".........");
		System.out.println("object created:"+counter);
	}
}

//D()
//.....
//D(int)
//.....
//D()
//.....
//D(int)
//.....
//object created:4