class S 
{
	int i;
}
class T
{
	S s1 = new S();//
	int j;
	T(int i, int j)
	{
		s1 = new S();
		s1.i = i;
		this.j = j;
	}

	public static void main(String[] args) 
	{
		T t1 = new T(10,20);
		System.out.println(t1.s1.i+":"+t1.j);
	}
}

//10:20