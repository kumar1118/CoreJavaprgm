class Q 
{
	int x;
}
class R 
{
	int y;
	Q q1;
	R(int y, Q q1)
	{
		this.y = y;
		this.q1 = q1;
	}

	public static void main(String[] args) 
	{
		R r1 = new R(10, new Q());
		System.out.println(r1.y);
		System.out.println(r1.q1.x);
	}
}


//10
//0