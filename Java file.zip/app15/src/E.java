class E 
{
	int counter;
	E()
	{
		System.out.println("E()");
	}
	E(int i)
	{
		System.out.println("E(int)");
	}
	{
		counter++;
	}
	public static void main(String[] args) 
	{
		E e1 = new E();
		System.out.println(".........");
		E e2 = new E(10);
		System.out.println(".........");
		E e3 = new E();
		System.out.println(".........");
		E e4 = new E(10);
		System.out.println(".........");
		System.out.println(e1.counter);
		System.out.println(e2.counter);
		System.out.println(e3.counter);
		System.out.println(e4.counter);
	}
}

//E()
//.....
//E(int)
//.....
//E()
//.....
//E(int)
//.....
//1
//1
//1
//1