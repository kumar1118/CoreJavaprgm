class G 
{
	int i;
	static void test1(G g1, G g2)
	{
		int k = g1.i;
		g1.i = g2.i;
		g2.i = k;
	}
	public static void main(String[] args) 
	{
		G g1 = new G();
		G g2 = new G();
		g1.i = 10;
		g2.i = 20;
		System.out.println(g1.i + ":" +g2.i);
		test1(g1,g2);
		System.out.println(g1.i + ":" +g2.i);
	}
}

//10:20
//20:10

//int k = g1.i;
	//	g1.i = g2.i;
	//	g2.i = k;

	// swapping here