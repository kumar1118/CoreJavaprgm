class I 
{
	int x;
}
class J 
{
	int y;
	I obj;
	public static void main(String[] args) 
	{
		J j1 = new J();
		System.out.println(j1.y);
		System.out.println(j1.obj);
		System.out.println(j1.obj.x);
	}
}

//has a relationship b/w j and i