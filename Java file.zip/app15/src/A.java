class A 
{
	static int i;

	void test()
	{
		i = 20;
	}
	public static void main(String[] args) 
	{
		System.out.println("main1:"+i);
		A a1 = new A();
		a1.test();
		System.out.println("main2:"+i);
	}
}


//main1:0
//main2:20