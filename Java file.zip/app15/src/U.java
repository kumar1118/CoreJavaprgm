class Mail 
{
	String username;
	String password;
	Mail(String username, String password)
	{
		this.username = username;
		this.password = password;
	}
}
class Address
{
	String houseNo;
	String streetName;
	Mail Mail;
	Address(String houseNo, String streetName, String username, String password)
	{
		this.houseNo = houseNo;
		this.streetName = streetName;
		Mail = new Mail(username, password);
	}
}
class Person
{
	String firstName;
	String lastName;
	Address address;
	
	Person(String firstName, String lastName, String houseNo, String streetName, String username, String password)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		address=new Address(houseNo, streetName, username, password);
	}
}
class U
{
	public static void main(String[] args) 
	{
		Person p1 = new Person("vijay", "test", "123/B", "BTM", "user1", "india");
		System.out.println(p1.firstName);
		System.out.println(p1.lastName);
		System.out.println(p1.address.houseNo);
		System.out.println(p1.address.streetName);
		System.out.println(p1.address.Mail.username);
		System.out.println(p1.address.Mail.password);
		
	}
}
