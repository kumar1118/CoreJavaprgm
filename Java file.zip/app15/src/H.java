class H 
{
	int x;
	void test(H obj)
	{
		int k = x;
		x = obj.x;
		obj.x = k;
	}
	public static void main(String[] args) 
	{
		H h1 = new H();
		H h2 = new H();
		h1.x = 1;
		h2.x = 2;
		System.out.println(h1.x + ":" +h2.x);
		h1.test(h2);
		System.out.println(h1.x + ":" +h2.x);
	}
}

//1:2
//2:1