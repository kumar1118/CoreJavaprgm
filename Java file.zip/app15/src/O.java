class O 
{
	int x;
}
class P
{
	int y;
	O o1 = new O();
	public static void main(String[] args) 
	{
		P p1 = new P();
		System.out.println(p1.y);
		System.out.println(p1.o1.x);
	}
}


//0
//0