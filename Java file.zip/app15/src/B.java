class B 
{
	static int counter;

	B()
	{
		counter++;
	}
	
	public static void main(String[] args) 
	{
		B b1 = new B();
		B b2 = new B();
		B b3 = new B();
		B b4 = new B();
		
		System.out.println(counter);
	}
}
