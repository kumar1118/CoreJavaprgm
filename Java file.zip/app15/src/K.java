class K
{
	int x;
}
class L
{
	K k1;
	int y;
	String z;
	public static void main(String[] args) 
	{
		L obj = new L();
		System.out.println(obj.k1);
		System.out.println(obj.y);
		System.out.println(obj.z);
		System.out.println(obj.k1.x);
		//System.out.println(obj.z.length());
	}
}

//null
//0
//null
//null pointer exception
//obj.z...is String type