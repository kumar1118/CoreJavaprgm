class C 
{
	static int i;
	C()
	{
		i++;
	}
	C(int j)
	{
		i++;
	}
	public static void main(String[] args) 
	{
		C c1 = new C();
		C c2 = new C(20);
		C c3 = new C();
		C c4 = new C();
		C c5 = new C(30);
		
		System.out.println("no of object created:"+i);
	}
}

//no of object created:5