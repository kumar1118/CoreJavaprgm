class F 
{
	static int counter;

	{
		counter++;
	}
	public static void main(String[] args) 
	{
		F f1 = new F();					//1
		System.out.println(f1.counter);	//1
		F f2 = new F();					//2
		System.out.println(f2.counter);//2
		F f3 = new F();					//3
		System.out.println(f3.counter);//3
		F f4 = new F();					//4
		System.out.println(f4.counter);//4
	}
}
//1
//2
//3
//4

//here using default constructor.