class Q17
{
	public static void main(String[] args) 
	{
		for(char i = 'a', k = 1; i <= 'f';i++, k++)
			{
		for(char j = 'a'; j<='f'; j++)
			{
				if(j<i)
				{
				System.out.print(" ");
				}
				else
				{
		System.out.print((char)(j - k + 1));
				}
			}
			System.out.println();
			}
	}
}