class Q18
{
	public static void main(String[] args) 
	{
		for(char i = 'a'; i <='f';i++)
			{
		for(char j = 'a'; j<='f'; j++)
			{
				if(j<i)
				{
				System.out.print(" ");
				}
				else
				{
		System.out.print(j);
				}
			}
			System.out.println();
			}
	}
}