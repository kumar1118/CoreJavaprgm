class Q5
{
	public static void main(String[] args) 
	{
	for(char i = 'a',rowNum=1;i<='f';i++,rowNum++)
		{
		for(char j='a', colsNum=1; j<=i;j++,colsNum++)
		
			{
		
				System.out.print(i);
			}
		System.out.println();
		}
	}
}

//a
//bb
//ccc
//dddd
//eeeee
//ffffff
