class Q11
{
	public static void main(String[] args) 
	{
		for(char i = 'f'; i >= 'a';i--)
			{
		for(char j = 'a'; j<=i; j++)
			{
				System.out.print(j);
		}
		System.out.println();
			}
	}
}