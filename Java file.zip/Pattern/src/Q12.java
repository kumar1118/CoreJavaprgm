class Q12
{
	public static void main(String[] args) 
	{
		for(char i = 'p'; i <= 'u';i++)
			{
		for(char j = i; j<='u'; j++)
			{
				System.out.print(j);
		}
		System.out.println();
			}
	}
}