class Q9
{
	public static void main(String[] args) 
	{
	    int	totalRows = 6;
		for(int i = totalRows; i>=1;i--)
			{
		for(int j =(totalRows - i + 1); j<=totalRows; j++)
			{
			System.out.print(j);
		    }
		    System.out.println();

			}
	}
}
