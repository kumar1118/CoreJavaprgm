class Q133
{
	public static void main(String[] args) 
	{
		for(int i = 6; i >= 1;i--)
			{
		for(int j = 1, colsNum= i; j<=i; j++,colsNum--)
			{
				System.out.print('*');
		}
		System.out.println();
			}
	}
}