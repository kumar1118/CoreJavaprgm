class Q4
{
	public static void main(String[] args) 
	{
		for(int i=9,rowcount=1;i>=5;i--,rowcount++)
		{
			for(int j=i,colscount=1;colscount<=rowcount;j--,colscount++)
			{
				System.out.print(j);
			}
			System.out.println();
		}
	}
}
//9
//87
//765
//6543
//54321