class Q6
{
	public static void main(String[] args) 
	{
		for(char i = 'a'; i<= 'f'; i++)
			{
		for(char j = 'a';j<= i; j++)
			{
				System.out.print(j);
			}
		System.out.println();
		}
	}
}

//a
//ab
//abc
//abcd
//abcde
//abcdef