class Q33
{
	public static void main(String[] args) 
	{
		int rows = 11;
		int cols = 11/2 + 1;
		for(int i = 1; i <= rows; i++)
		{
			for(int j = 1;( i <= cols ? j <= i : j <= (rows - i +1)) ; j++)
			{
				
		System.out.print(j - 1);
			}
		System.out.println();
		}
	}
}
//0
//01
//012
//0123
//01234
//012345
//01234
//0123
//012
//01
//0