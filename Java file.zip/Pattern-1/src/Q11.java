class  Q11
{
	public static void main(String[] args) 
	{
		for (int i=1;i<=5;i++) // for 5 loops
		{
			for (int j =5-i;j >= 0;j--) //for spaces
			{
			System.out.print(" ");
			}
 
			for (int k = i;k >= 1;k--) // to display values
			{
			System.out.print(k+" ");
			}
			for (int x=2;x<=i;x++) //2nd part right side
			{
			System.out.print(x+" ");
			}
			System.out.println();

		}
	}
}

//    1
//   212
//  32123
// 4321234
//543212345
