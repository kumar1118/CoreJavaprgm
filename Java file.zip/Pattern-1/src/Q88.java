class Q88
{
	public static void main(String[] args) 
	{
		int i,s,j,k;
		
		for(i = 1; i <= 5; i++)
		{
			for (s = 1; s <= 5-i  ;s++ )
				{
				System.out.print(" ");
				}
				for(j = 1; j <= i; j++)
				{
				System.out.print(j+" ");
				}
				for (k=i-1;k>=1;k--)
				{
				System.out.print(k+" "); //printing back values
				}
				System.out.println();
				}
		}
}
//    1
//   121
//  12321
// 1234321
//123454321