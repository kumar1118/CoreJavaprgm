class  Q111
{
	public static void main(String[] args) 
	{
		for (int f=1;f<=5;f++) // for 5 loops
   {
		for (int sp=5-f;sp>=0;sp--) //for spaces
		{
		System.out.print(" ");
		}
 
		for (int s=f;s>=1;s--) // to display values
		{
		System.out.print(s+" ");
		}
		for (int x=2;x<=f;x++) //2nd part right side
		{
		System.out.print(x+" ");
		}
		System.out.println();
		}
		for (int f=4;f>=1;f--) // for 5 loops
		{
		for (int sp=5-f;sp>=0;sp--) //for spaces
		{
		System.out.print(" ");
		}
 
		for ( int s=f;s>=1;s--) // to display values
		{
		System.out.print(s+" ");
		}
		for ( int x=2;x<=f;x++) //2nd part right side
		{
		System.out.print(x+" ");
		}
		System.out.println();
		}
	}
}

//    1
//   212
//  32123
// 4321234
//543212345
// 4321234
//  32123
//   212
//    1