class Q8_ 
{
	public static void main(String[] args) 
	{
		for( int i = 6; i >=1; i--)
		{
		for( int j = 6; j >=i; j--)
			{
		System.out.print(i);
			}
		System.out.println();
		}
		for( int i = 2; i <=6; i++)
		{
		for( int j = 6; j >=i; j--)
			{
		System.out.print(i);
			}
		System.out.println();
		}
	}
}
//6
//55
//444
//3333
//22222
//111111
//22222
//3333
//444
//55
//6