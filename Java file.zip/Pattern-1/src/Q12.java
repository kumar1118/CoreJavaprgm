class Q12
{
	public static void main(String[] args) 
	{
		for(int i = 1; i <= 5;i++)
			{
		for(int j = 1; j<=5; j++)
			{
				if(j<i)
				{
				System.out.print(" ");
				}
				else
				{
		System.out.print(j - i + 1);
				}
			
			for(int k = i; k<=4; k++)
			{
				
		System.out.print(k);
				}
			
			System.out.println();
			}
		}
	}
}
