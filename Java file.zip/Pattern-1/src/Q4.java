class Q4
{
	public static void main(String[] args) 
	{
		int rows = 11;
		int cols = 11/2 + 1;
		for(int i = 1; i <= rows; i++)
		{
			for(int j = ( i <= cols ? i : (rows - i +1)) ; j > 0; j--)
			{
				
		System.out.print(j);
			}
		System.out.println();
		}
	}
}
//1
//21
//321
//4321
//54321
//654321
//54321
//4321
//321
//21
//1