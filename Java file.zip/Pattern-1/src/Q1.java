class Q1 
{
	public static void main(String[] args) 
	{
		int rows = 9;
		int cols = 9/2 + 1;
		for(int i = 1; i <= rows; i++)
		{
			for(int j = 1;( i <= cols ? j <= i : j <= (rows - i +1)) ; j++)
			{
				
		System.out.print('*');
			}
		System.out.println();
		}
	}
}
//*
//**
//***
//****
//*****
//****
//***
//**
//*