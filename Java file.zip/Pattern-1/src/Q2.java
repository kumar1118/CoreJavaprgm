class Q2 
{
	public static void main(String[] args) 
	{
		int rows = 11;
		int cols = 11/2 + 1;
		for(int i = 1; i <= rows; i++)
		{
			for(int j = 1;( i <= cols ? j <= i : j <= (rows - i +1)) ; j++)
			{
				
		System.out.print(j);
			}
		System.out.println();
		}
	}
}
//1
//12
//123
//1234
//12345
//1234
//123
//12
//1