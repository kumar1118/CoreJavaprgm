class Q3
{
	public static void main(String[] args) 
	{
		int rows = 11;
		int cols = rows/2 + 1;
		for(int i = 1; i <= rows; i++)
		{
			for(int j = 1;( i <= cols ? j <= i : j <= (rows - i +1)) ; j++)
			{
				
		System.out.print(i <= cols ? i : (rows - i + 1));
			}
		System.out.println();
		}
	}
}
//1
//22
//333
//4444
//55555
//666666
//55555
//4444
//333
//22
//1