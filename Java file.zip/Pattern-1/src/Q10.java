class Q10
{
	public static void main(String[] args) 
	{
		int i,s,j,k;
		
		for(i = 1; i <= 5; i++)   // five loop
		{
			for (s = 1; s <= 5-i  ;s++ ) // printing spaces
				{
				System.out.print(" ");
				}
				for(j = 1; j <= i; j++) //displays purpose
				{
				System.out.print(j+" ");
				}
				for (k= 2;k <= i ;k++)
				{
				System.out.print((j+k-2)+ " "); //printing back values
				}
				System.out.println();
				}
		}
}
//    1
//   123
//  12345
// 1234567
//123456789