class Q9
{
	public static void main(String[] args) 
	{
		int i,s,j,k;
		
		for(i = 1; i <= 5; i++)
		{
			for (s = 1; s <= 5-i  ;s++ )
				{
				System.out.print(" ");
				}
				for(j = 1; j <= i; j++)
				{
				System.out.print(j+" ");
				}
				for (k=i-1;k>=1;k--)
				{
				System.out.print(k+" "); //printing back values
				}
				System.out.println();
				}
		}
}
//    1
//   121
//  12321
// 1234321
//123454321

// itiration 1; i = 1; true   i++=2 .....row 1
//itiration 2; s = 1; 1 <=4; true; s++ = 2 ...printed four times " "//spaces
//itiration 3; j = 1; 1 <=1; true; j++ = 2....printed 1 at the fith position in first row
//itiration 4; j = 2; 2 <= 1; false,  move next step
//itiration 5; k = 0; 0 >= 1; false. move next step and printed nothing goto main for loop
//itiration 1; i = 2; true  i++ = 3.....row 2
//itiration 2; s = 1; 1 <= 3; true; s++ = 2 ...printed three times " "//spaces
//itiration 3; j = 1; 1 <= 2; true; j++ = 2....printed 1 at the fourth position in second row
//itiration 4; j = 2; 2 <= 2; true; j++ = 3....printed 2 at the fith position in second row and next time when j = 3 condition is false and move to next iritation
//itiration 5; k = 1; 1 >= 1; true. printed 1 and move to main for loop
//itiration 1; i = 3; true  i++ = 4.....row 3
//itiration 2; s = 1; 1 <= 2; true; s++ = 2 ...printed two times " "//spaces
//itiration 3; j = 1; 1 <= 3; true; j++ = 2....printed 1 at the third position in third row
//itiration 3; j = 2; 2 <= 3; true; j++ = 3....printed 2 at the forth position in third row
//itiration 3; j = 3; 3 <= 3; true; j++ = 4....printed 3 at the fifth position in third row when j = 4 condition is false and move to next step
//itiration 5; k = 2; 2 >= 1; true. printed 2 at the sixth position in third row
//itiration 5; k = 1; 1 >= 1; true. printed 1 at the seventh position in third row then move to main for loop.......