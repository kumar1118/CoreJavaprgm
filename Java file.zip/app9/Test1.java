class  Test1
{
	public static void main(String[] args) 
	{
		//decimal to binafry
		int number = 123;
		String binaryString = Integer.toBinaryString(number);
		System.out.println("decimal to binary:"+ binaryString);
		//decimal to octal
		String octalString = Integer.toOctalString(number);
		System.out.println("decimal to octal:"+ octalString);
		//decimal to hexadecimal
		String hexString = Integer.toHexString(number);
		System.out.println("decimal to hexadecimal:"+ hexString);
		//decimal to octal
		
	}
}
