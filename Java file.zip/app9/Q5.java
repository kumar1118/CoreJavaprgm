import java.util.Scanner;
class  Q5
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a line of content");
		String s1 = sc.nextLine();
		System.out.println("you have entered:" +s1);
	}
}
