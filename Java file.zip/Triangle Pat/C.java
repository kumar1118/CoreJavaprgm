import java.util.Scanner;
class C
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number of rows");
		int rows = sc.nextInt();
		for(int i = 1; i <= rows; i++)
		{
		for(int j = 1; j <= i; j++)
			{ 
			System.out.print(j+"");
			}
			System.out.println();
		}
		for(int i = rows; i >= 1; i--)
		{
		for(int j = 1; j <=i ; j++)
			{ 
			System.out.print(j+"");
			}
			System.out.println();
		}
	}
}
//enter number of rows
//5
//1
//12
//123
//1234
//12345
//1234
//123
//12
//1