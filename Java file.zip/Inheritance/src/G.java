class G extends Object
{
	G()
	{
		super();
		System.out.println("G()");
	}
}
class H extends G
{
	H()
	{
		//super();
		System.out.println("H()");
	}
	public static void main(String[] args) 
	{
		
		H h1 = new H();
		System.out.println("Hello World!");
	}
}

//G() class constructor is not iherited to H
//compiler only providing default constructor always no arg.
//every constructor should be either super calling statement or this calling statement.
//hello world!
//chain of constructor are involving while creating a constructor


