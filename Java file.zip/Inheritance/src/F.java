class E 
{
	int i;
	static int j;
	void test1()
	{
		System.out.println("from test1");
	}
	void test2()
	{
		System.out.println("from test2");
	}
}
class F extends E
{
	public static void main(String[] args) 
	{
		int m;
		static int n;
		void test3()
		{
			System.out.println("from test3");
		}
		static void test4()
		{
			System.out.println("from test4");
		}
		
			F.test2();
			F.test4();
		System.out.println(f1.j);
		System.out.println(f1.n);
		F f1 = new F();
		System.out.println(f1.i);
		System.out.println(f1.m);
		f1.test1();
		f1.test3();
	}
}
//initialization member of inheritance in not
//constructive,IIB,SIB are not involving in the inheritance