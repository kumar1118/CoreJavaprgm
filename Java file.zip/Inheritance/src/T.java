class S
{
	S(int i)
	{
		System.out.println("S(int)");
	}
}  
class  T extends S
{
	T(int i)
	{
		super(i);
		System.out.println("T(int)");
	}
	public static void main(String[] args) 
	{
		S s1 = new S(10);
		
		System.out.println("............");
		T t1 = new T(10);	
	}
}

//S(int)
//..........
//S(int)
//T(int)

