class O 
{
	O(int i)
	{
		System.out.println("O(int)");
	}
}
class P extends O
{
	P()
	{
		System.out.println("P()");
	}
}
