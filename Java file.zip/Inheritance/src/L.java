class I 
{
	I()
	{
		System.out.println("I()");
	}
}
class J extends I
{
	J()
	{
		System.out.println("J()");
	}
}
class K extends J
{
	K()
	{
		System.out.println("K()");
	}
}
class L extends K
{
	L()
	{
		System.out.println("L()");
	}

	public static void main(String[] args) 
	{
		L obj1 = new L();
		System.out.println("...................");
		J obj2 = new J();
		System.out.println("...................");
		K obj3 = new K();
		System.out.println("...................");
		I obj4 = new I();
		System.out.println("...................");
	}
}

//chain of cons are involving are called
//I()
//j()
//K()
//L()
//...........
//I()
//j()
//...........
//I()
//j()
//K()
//...........
 //I()
 //..........



