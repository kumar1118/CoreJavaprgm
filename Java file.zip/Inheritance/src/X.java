class W
{
	W(int i, int j)
	{
		System.out.println("W(int,int)");
	}
}
class X extends W
{
	X()
	{
		super(10,20);
		System.out.println("X()");
	}
	X(int i)
	{
		super(10,i);
		System.out.println("x(int)");
	}
	X(int i, int j)
	{
		super(i,i);
		System.out.println("x(int,int)");
	}
	public static void main(String[] args) 
	{
		X x1 = new X(1,0);
		System.out.println("............");
		X x2 = new X(1);
		System.out.println("............");
		X x3 = new X();
		System.out.println("............");
	}
}

//W(int,int)
//X(int,int)
//...........
//W(int,int)
//X(int)
//...........
//W(int,int)
//X()
//...........