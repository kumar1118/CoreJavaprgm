class U  
{
	U(int i)
	{
		System.out.println("U(int)");
	}
}
class V extends U  
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
