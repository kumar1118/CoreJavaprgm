class Q 
{
	Q(int i)
	{
		System.out.println("Q()");
	}
}
class R extends Q
{
	R()
	{
		super(10);
		System.out.println("R()");
	}

	public static void main(String[] args) 
	{
		Q q1 = new Q(20);
		System.out.println("...........");
		R r1 = new R();
	}
}


//Q()
//.......
//Q()
//R()
