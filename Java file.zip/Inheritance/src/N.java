class M 
{
	M(int i)
	{
		
		System.out.println("M(int)");
	}
}
class N extends M 
{
	N(int i)
	{
		
		System.out.println("N(int)");
	}

	public static void main(String[] args) 
	{
		//M m1 = new M(90);
		System.out.println("..........");
		//N n1 = new N(90);
		System.out.println("..........");
	}
}

// compiler error
//becose of compiler is providing no argument cons.
// there is no availabe no arg cons in the M class.