class M 
{
	M()
	{
		//super();
		System.out.println("M()");
		super(); //super calling statement is only the first statement in the constructor.
	}

	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
