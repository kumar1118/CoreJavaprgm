class E
{
	E()
	{
		this(10);
		System.out.println("E()");
	}
	E(int i)
	{
		
		System.out.println("E(int)");
	}
	
	{
		
		System.out.println("E-IIB");
	}
}
class F
{

	public static void main(String[] args) 
	{
		E e1 = new E();
		System.out.println("..........");
		E e2 = new E(30);
		System.out.println("..........");
	}
}

//E-IIB
//E(int)
//E()
//..........
//E-IIB
//E(int)
//..........





