class N 
{
	N()
	{
		System.out.println("N()");
	}
}
class O extends N
{
	O()
	{
		//super();
		System.out.println("O()");
		super(); // call statement should be the first statement in the constructor.
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
