class G
{
	G()
	{
		System.out.println("G()");
	}
	
	{
		System.out.println("G-IIB");
	}
	G(int i)
	{
		this();
		System.out.println("G(int)");
	}
}
class  H extends G
{
	H()
	{
	System.out.println("H()");
	}		
		
	{
	System.out.println("H-IIB");
	}
	H(int i)
	{
	super(i);
	System.out.println("H(int)");
	}
		public static void main(String[] args)

	{
	
		H h1 = new H();
		System.out.println("............");
		H h2 = new H(20);
		System.out.println("............");
		G g1 = new G();
		System.out.println("............");
		G g2 = new G(20);
		System.out.println("............");
	}
}
//G-IIB
//G()
//H-IIB
//H()
//.........
//G-IIB
//G()
//G(int)
//H-IIB
//H(int)
//.........
//G-IIB
//G()
//.......
//G-IIB
//G()
//G(int)
//.......









