class A 
{
		int i;
}
class S
{
	A a1;
	int j;
	public static void main(String[] args) 
	{
		S s1 = new S();
		s1.j = 10;
		s1.a1 = new A();
		s1.a1.i = 20;

		System.out.println(s1.j);
		System.out.println(s1.a1.i);
	}
}

//10
//20
//has a relationship:this kind of program called







