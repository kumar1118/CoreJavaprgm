class I
{
	I()
	{
		System.out.println("I()");
	}
	static
	{
		System.out.println("I-SIB1");
	}
	
	{
		System.out.println("I-IIB1");
	}
	I(int x)
	{
		this();
		System.out.println("I(int)");
	}
	
	{
		System.out.println("I-IIB2");
	}
}
class  J extends I
{
	J(int x, int y)
	{
		System.out.println("J(int,int)");
	}
	J(int x)
	{
		System.out.println("J(int)");
	}
	J()
	{
		this(9, 8);
		System.out.println("J()");
	}
	static
	{
		System.out.println("J-SIB");
	}
	
	{
		System.out.println("J-IIB1");
	}
}
class K
{
	public static void main(String[] args) 
	{
		I obj1 = new I();
		System.out.println("...........");
		I obj2 = new I(20);
		System.out.println("...........");
		J objj3 = new J(90);
		System.out.println("...........");
		J obj4 = new J(90,34);
		System.out.println("...........");
		J obj5 = new J();
		System.out.println("...........");
		
	}
}
class L
{
	public static void main(String[] args) 
	{
		J obj1 = new J();
		System.out.println("...........");
		J obj2 = new J(20);
		System.out.println("...........");
		J objj3 = new J(90,80);
		System.out.println("...........");
		I obj4 = new I(90);
		System.out.println("...........");
		I obj5 = new I();
		System.out.println("...........");
		
	}
}
