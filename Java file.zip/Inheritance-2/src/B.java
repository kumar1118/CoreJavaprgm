class A 
{
	A()
	{
		System.out.println("A()");
	}
	
	{
		System.out.println("A-IIB");
	}

	A(int i)
	{
		System.out.println("A(int)");
	}
}
class B
{

	public static void main(String[] args) 
	{
		A a1 = new A();
		System.out.println("............");
		A a2 = new A(20);
	}
}

//A-IIB
//A()
//..........
//A-IIB
//A(int)


















