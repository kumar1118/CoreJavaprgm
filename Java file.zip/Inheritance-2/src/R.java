class  Q
{
	Q()
	{
		System.out.println("Q()");//two times constructor is not allow for the same object creations.
	}
}
class R extends Q
{
	R()
	{
		System.out.println("R()");
	}
	R(int i)
	{
		System.out.println("R(int)");
		this();  // call statement should be the first statement in the constructor.
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}

//compile time Error

