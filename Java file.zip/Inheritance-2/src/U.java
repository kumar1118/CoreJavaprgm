class C 
{
	int i;
}
class U
{
	int j;
	C c1 = new C();
	void test()
	{
		System.out.println(c1.i);
		System.out.println(j);
	}
	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}

//done