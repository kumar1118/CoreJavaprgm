class P
{
	P()
	{
		System.out.println("P()");
		this(10);// call statement should be the first statement in the constructor.
	}
	P(int i)
	{
		System.out.println("P(int)");
		
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}


//compile time Error
