class D
{
	int i;
}
class V extends D
{
	int j;
	void test()
	{
		System.out.println(i);
		System.out.println(j);
	}
	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}

//done