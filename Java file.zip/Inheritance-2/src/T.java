class B 
{
	int i;
}
class T extends B
{
	int j;
	public static void main(String[] args) 
	{
		T t1 = new T();
		System.out.println(t1.i);
		System.out.println(t1.j);
	}
}
//0
//0



