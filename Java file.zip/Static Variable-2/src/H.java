class H 
{
	static int i = test1();
		static
	{
		System.out.println("SIB:"+i);
		i = 10;
	}
	static int test1()
	{
		System.out.println("test1:"+i);
		return 20;
	}
	public static void main(String[] args) 
	{
		
		System.out.println("main:"+i);
	}
}
