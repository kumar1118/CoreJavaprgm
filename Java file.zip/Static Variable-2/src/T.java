class T 
{
	static int i = test1();
	static
	{
		System.out.println("sib-begin:"+i);
		main(null);
		System.out.println("sib-end:"+i);
	}
	static int test1()
	{
		System.out.println("test1-begin:"+i);
		i = 20;
		main(null);
		System.out.println("test1-end:"+i);
		return 10;
	}
		public static void main(String[] args) 
	{
		System.out.println("main:"+i);
		i = 30;
	}
}
//test1-begin:0
//main:20
//test1-end:30
//sib-begin:10
//main:10
//sib-end:30
//main:30