class S
{
	static int i = test1();
	static int test1()
	{
		System.out.println("from test1:"+i);
		main(null);
		System.out.println("from test1:"+i);
		return 10;
	}
	public static void main(String[] args) 
	{
		System.out.println("main:"+i);
		i = 20;
	}
}
// from test1:0
//main:0
//from test1:20
//main:10