class R 
{
	static
	{
		System.out.println("sib-begin");
		main(null);
		System.out.println("sib-end");
	}
	public static void main(String[] args) 
	{
		System.out.println("main");
	}
}
