class M 
{
	static
	{
		i = 10;
	}
	static int i;
	public static void main(String[] args) 
	{
		System.out.println("main:"+i);
	}
}
