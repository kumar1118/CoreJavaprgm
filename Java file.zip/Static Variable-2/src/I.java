class I 
{
	static int i;
	i = 10;
	public static void main(String[] args) 
	{
		System.out.println("main:"+i);
	}
}
