class P
{
	static void test()
	{
		System.out.println("from main:"+i);
		i = 10;
	}
	static int i;
	public static void main(String[] args) 
	{
		System.out.println("main1:"+i);
		i = 20;
		test();
		System.out.println("main2:"+i);
	}
}

//main1:0
//from main:10
//main2:10