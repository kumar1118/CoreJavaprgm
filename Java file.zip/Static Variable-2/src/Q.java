class Q 
{
	public static void main(String[] args) 
	{
		System.out.println("main:" + i + "," + j);
	}
	static int i;
	static int j = 20;
}
// Output is 
// main:0,20