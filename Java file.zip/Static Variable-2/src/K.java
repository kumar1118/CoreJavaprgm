class K 
{
	System.out.println("K-class");
	public static void main(String[] args) 
	{
		System.out.println("main");
	}
}
// sop is no a member of the claSS
