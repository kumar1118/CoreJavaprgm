class O 
{
	static
	{
		i = 10;
	}
	static int i = 5;
	public static void main(String[] args) 
	{
		System.out.println("main:"+i);
	}
}
// becose of in is already initialised thats why they can not go inside SIB.
// we can go inside the SIB but i can not use 
//o/p is main:5