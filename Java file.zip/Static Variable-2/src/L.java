class L 
{
	static int i = test1();
	static int test1()
	{
		System.out.println("test1:"+i);
		return 20;
	}
	static
	{
		System.out.println("SIB1:"+i);
		i = 30;
	}
	public static void main(String[] args) 
	{
		System.out.println("main:"+i);
		i = 40;
	}
		static
	
	{
		System.out.println("SIB2:"+i);
		i = 50;
	}
}
