class J 
{
	static int x;
	public static void main(String[] args) 
	{
		System.out.println(x);
	}
	x = 10;
}
// error 
// x = 10 is not a method member