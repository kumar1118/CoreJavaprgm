class N
{
	static
	{
		System.out.println(i);
	}
	static int i;
	public static void main(String[] args) 
	{
		System.out.println("main:"+i);
	}
}
// three method SIB, global variable and main method
//SIB is a perfect initializer
//compile time error
//illegal forword reference