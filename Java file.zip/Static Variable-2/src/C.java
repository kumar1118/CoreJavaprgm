class C 
{
	static int i = 10;
	static int j = test();
	static int test()
	{
		return i;
	}
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		System.out.println(i);
		System.out.println(j);
		System.out.println("main end");
	}
}
