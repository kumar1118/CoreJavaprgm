class R 
{
  static int i = 10;	
}
//run time Error
// main mathod is not found