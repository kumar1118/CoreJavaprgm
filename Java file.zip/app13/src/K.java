class J 
{
	public static void main(String[] args) 
	{
		System.out.println("from J main");
	}
}
class K
{
	public static void main(String[] args) 
	{
		System.out.println("from k main begin");
		J.main(null);
		System.out.println("from K main end");
	}
}

//while running class J the output is "main J from"
//while running class K the output is 
//from K main begin
//from J main
//from K main end


//
