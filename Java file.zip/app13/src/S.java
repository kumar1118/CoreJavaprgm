class S 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		System.out.println(R.i);
		System.out.println("main end");
	}
}
//main begin
//10
//main end