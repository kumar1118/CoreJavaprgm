class C
{
	static void test1()
	{
	System.out.println("from C.test1");
	}
}
class D
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		C.test1();
		System.out.println("main end");
	}
}

//main begin
//from C.test1
//main end