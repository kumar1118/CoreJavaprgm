class P 
{
	static void test1()
	{
		System.out.println("from P.test1");
	}
	static
	{
		System.out.println("from P.SIB");
	}
}
class Q 
{
	
	static
	{
		System.out.println("from Q.SIB");
	}
	public static void main(String[] args) 
	{
		System.out.println("Q.main begin");
		P.test1();
		P.test1();
		P.test1();
		P.test1();
		System.out.println("Q.main end");
	}
}
//from Q.SIB
//Q.main begin
//from P.SIB
//from P.test1
//from P.test1
//from P.test1
//from P.test1
//Q.main end