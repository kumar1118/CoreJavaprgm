class W 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		V.method1();
		System.out.println("main end");

	}
}
//compile time error due to
// class name can not find in the folder
//always choose class name as a folder name
//