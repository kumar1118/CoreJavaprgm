class Abcjava
{
	static void method1() 
	{
		System.out.println("from method1");
	}
}
