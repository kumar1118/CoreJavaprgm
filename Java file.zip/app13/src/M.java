class L 
{
	public static void main(String[] args) 
	{
		System.out.println("L main begin");
		M.main(args);
		System.out.println("L main end");
	}
}
class M
{
	public static void main(String[] args) 
	{
		System.out.println("M main begin");
		}
}
////while running class M the output is "M main begin"
//while running class L the output is 
//L main begin
//"M main begin"
//L main end
// while using null insteed of args result will be same.