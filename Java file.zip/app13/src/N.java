class N 
{
	static int i;
	static
	{
	
		System.out.println("from N.SIB");
	}
}
class O
{
	static
	{
		System.out.println("from O.SIB");
	}
	public static void main(String[] args) 
	{
		System.out.println("O.main begin");
		System.out.println(N.i);
		System.out.println("O.main end");
	}
}

//from O.SIB
//O.main begin
//from N.SIB
//0
//O.main end