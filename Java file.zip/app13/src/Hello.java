class A 
{
	static int i;
}
class B
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		System.out.println(A.i);
		System.out.println("main end");
	}
}
//in one java file more than one class can be develope
//if all classes are not public so you can choose any class name
//in one java file only one class is public
//

//Ans main begin
//    0
//    main end