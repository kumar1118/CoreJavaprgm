class U 
{
	static
	{
		System.out.println("U.SIB");
	}
	public static void main(String[] args) 
	{
		System.out.println("U.main begin");
		T.test1();
		System.out.println("U.main end");
	}
}
//U.SIB
//U.main begin
//T.SIB
//T.test1
//U.main end