class I 
{
	public static void main(String[] args) 
	{
		System.out.println("main from I");
	}
}
class J
{
	public static void main(String[] args) 
	{
		System.out.println("main from J");
	}
}
//any no of classes have main method.
//while running class I the output is "main from I"
//while running class J the output is "main from J"