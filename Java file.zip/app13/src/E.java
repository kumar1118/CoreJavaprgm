class E 
{
	static int i = 20;
}
class F
{
	static void test1()
	{
		System.out.println("from F.test1:"+E.i);
	}
}
class G
{
	static void test2()
	{
		System.out.println("from G.test2 begin:"+E.i);
		F.test1();
		System.out.println("from G.test2 end:"+E.i);
	}
}
class H
{
	public static void main(String[] args) 
	{
		System.out.println("H main begin:"+E.i);
		F.test1();
		System.out.println("...............");
		G.test2();
		System.out.println("H main end:"+E.i);
	}
}
//Output....
//H main begin:20
//from F.test1:20
//...............
//from G.test2 begin:20
//from F.test1:20
//from G.test2 end:20
//H main end:20