class T 
{
	static
	{
		System.out.println("T.SIB");
	}
	static void test1() 
	{
		System.out.println("T.test1");
	}
}
