class Q49
{
	public static void main(String[] args) 
	{
		int i = Integer.parseInt(args[0]);
		int j = Integer.parseInt(args[1]);

		if(i == 6 || j == 6 || (i + j) == 6 || (i - j) == 6)
		{
			System.out.println("true");
		}
		else 
		{
			System.out.println("no symetry");
		}
	}
}
