class Q15
{
	public static void main(String[] args) 
	{
		int sum = 0;
		for(int i = 25; i <= 125; i++)
		{
			sum += i;//sum = sum + i
		}
		System.out.println(sum);
	}
}
