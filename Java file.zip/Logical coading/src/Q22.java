//2 popwer 10.

class Q22 
{
	public static void main(String[] args) 
	{
		int result = 1;
		for(int i = 1; i <= 10; i++)
		{
			result *= 2;//result = result * 2;
		}
		System.out.println(result);
	}
}
