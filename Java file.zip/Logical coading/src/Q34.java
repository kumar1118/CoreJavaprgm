class Q34
{
	public static void main(String[] args) 
	{
		
		int num = Integer.parseInt(args[0]);
		System.out.println("last two digit:"+num % 100);
	}
}
