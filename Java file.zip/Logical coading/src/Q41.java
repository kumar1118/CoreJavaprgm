import java.util.Scanner;
class Q41
{
	public static void main(String[] args) 
	{
		int a, area;
      System.out.println("Enter value of a");
      Scanner in = new Scanner(System.in);
      a = in.nextInt();
	  area = a * a;
		System.out.println("area of Rectangle:"+area);
	}
}
