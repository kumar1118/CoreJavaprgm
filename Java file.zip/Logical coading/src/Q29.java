class Q29
{
	public static void main(String[] args) 
	{
		
		int i =  Integer.parseInt(args[0]); 
		int j =  Integer.parseInt(args[1]); 
		int k =  Integer.parseInt(args[2]); 
		/*
		if(i < j)
		{
			if(i < k)
			{
			System.out.println(i);
			}
			else
			{
			System.out.println(k);
			}
		}
		else
		{
			if(j<k)
			{
				System.out.println(j);
			}
			else
			{
			System.out.println(k);
			}
			*/
			/*
			int min = (i < j) ? (i < k ? i:k) : (j < k ? j: k);
			System.out.println(min);
			*/

			System.out.println((i < j) ? (i < k ? i:k) : (j < k ? j: k));
		
	}
}