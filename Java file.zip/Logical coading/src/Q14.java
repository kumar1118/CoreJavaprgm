//print 100 to 1 by reverse order only even.

class Q14 
{
	public static void main(String[] args) 
	{
		/*
		for(int i = 100; i > 1; i = i - 2)//i = i - 2 or i -= 2//
		{
		System.out.print(i+",");
		}
		*/
		for(int i = 100; i > 0; i--)
		{
			if(i % 2 == 0)
			{
		System.out.print(i+",");
			}
		}
	}
}
