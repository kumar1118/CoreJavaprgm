//Harmonic sum
class Q24
{
	public static void main(String[] args) 
	{
		double sum = 0;
		for(double i = 65.0; i > 0.0; i--)
		{
			sum += 1/i;
		}
		System.out.println(sum);
	}
}
