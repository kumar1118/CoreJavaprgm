class Q5
{
	public static void main(String[] args) 
	{
		int num = Integer.parseInt(args[0]);
		int sqr = num*num;
		System.out.println("square of:"+num+"is:"+ sqr);
	}
}