class Q20 
{
	public static void main(String[] args) 
	{
		int sum = 0;
		for(int i = 1; i < 45; i++)
		{
			sum += i;
		}
		double avg = (double)sum/44;
		System.out.println("average is:"+avg);
	}
}
