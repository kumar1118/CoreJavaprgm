class Q1 
{
	public static void main(String[] args) 
	{
		int marks = Integer.parseInt(args[0]);
		if (marks >50)
		{
		System.out.println("pass");
		}
		else
		{
		System.out.println("fail");
		}
	}
}
