class Q26 
{
	public static void main(String[] args) 
	{
		for(int i = 1; i <= 8; i++)//row purpose
		{
			for(int j = 1; j <= 5; j++)//column purpose
			{
				System.out.print(5);
			}
		System.out.println();
		}
	}
}
