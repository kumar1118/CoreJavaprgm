class Q52
{
	public static void main(String[] args) 
	{
		int num = Integer.parseInt(args[0]);
		int middle = num / 2;
		boolean isPrime = true;
		for(int i = 2; i <= middle; i++)
		{
			if(num % i == 0)
			{
				isPrime = false;
				break;
			}
		}
		System.out.println(num + "is prime:"+ isPrime);
		}
}
