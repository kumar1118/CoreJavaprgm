class Q57
{
	public static void main(String[] args) 
	{
		boolean isPrime = true;
		for(int i = 20; i < 60; i++)
		{
			for(int j = 2; j <= i / 2; j++)
			{
			if(i % j == 0)
			{
				isPrime = false;
				break;
			}
		}
		if(isPrime)
			{
			System.out.print(i + ",");
			}
			else
			{
				isPrime = true;
			}
		}
	}
}
//less then 10 prime number.
//2,3,5,7