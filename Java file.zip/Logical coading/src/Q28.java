class Q28
{
	public static void main(String[] args) 
	{
		
		int i =  Integer.parseInt(args[0]); 
		int j =  Integer.parseInt(args[1]); 
		/*
		if(i > j)
		{
			System.out.println("Max:"+i);
		}
		else
		{
			System.out.println("Max:"+j);
		}
		*/

		int max = 
	}
}