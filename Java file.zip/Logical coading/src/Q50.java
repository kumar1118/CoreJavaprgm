 class Q50
{
	public static void main(String[] args) 
	{
		int i = Integer.parseInt(args[0]);
		int j = Integer.parseInt(args[1]);
		int k = Integer.parseInt(args[2]);
		
		if(i < j && j < k )
		{
		System.out.println("true");
		}
		else
		{
		System.out.println("no symetry");
		}
	}
}
