class Q47
{
	public static void main(String[] args) 
	{
		int i = Integer.parseInt(args[0]);
		if(i % 3 == 0 || i % 5 == 0)
		{
			if(!(i % 3 == 0 && i % 5 == 0))
			{
			System.out.println("true");
			}
			else 
			{
			System.out.println("no symetry");
			}
		}
		else 
		{
			System.out.println("no symetry");
		}
	}
}
