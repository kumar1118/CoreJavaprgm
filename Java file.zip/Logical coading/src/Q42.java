import java.util.Scanner;
class Q42
{
	public static void main(String[] args) 
	{
		int r;
      System.out.println("Enter value of r");
      Scanner in = new Scanner(System.in);
      r = in.nextInt();
	  double area = (double)22/7 * r * r;
		System.out.println("area of Rectangle:"+area);
	}
}
