class Q21
{
	public static void main(String[] args) 
	{
		int sum = 0;
		for(int i = 25; i <= 85; i++)
		{
			sum += i;
		}
		double avg = (double)sum/61;
		System.out.println("average is:"+avg);
	}
}
