//Harmonic sum
class Q23 
{
	public static void main(String[] args) 
	{
		double sum = 0;
		for(double i = 1.0; i <= 45.0; i++)
		{
			sum += 1/i;
		}
		System.out.println(sum);
	}
}
