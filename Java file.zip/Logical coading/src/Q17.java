//sum of odd number below 50

class Q17 
{
	public static void main(String[] args) 
	{
		/*
		int sum = 0;
		for(int i = 1; i < 50; i += 2)
		{
			sum += i;
		}
		System.out.println(sum);
		*/
		int sum = 0;
		for(int i = 1; i < 50; i++)
		{
			if(i % 2 !=0)
			{
			sum += i;
			}
		}
		System.out.println(sum);
	}
}
