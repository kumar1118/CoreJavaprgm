import java.util.Scanner;
class Q36
{
   public static void main(String[] args)
   {
      /*
	  int x, y, temp;
      System.out.println("Enter x and y");
      Scanner in = new Scanner(System.in);
      x = in.nextInt();
	  y = in.nextInt();
      System.out.println("Before Swapping\nx = "+x+"\ny = "+y);
      temp = x;
      x = y;
      y = temp;
      System.out.println("After Swapping\nx = "+x+"\ny = "+y);
	  */


	  int i = Integer.parseInt(args[0]);
	  int j = Integer.parseInt(args[1]);
	  System.out.println("i ="+ i);
	  System.out.println("j ="+ j);
	  System.out.println("..........");
	  int k = i;
	  i = j;
	  j = k;
	  System.out.println("i ="+ i);
	  System.out.println("j ="+ j);
	  }
}