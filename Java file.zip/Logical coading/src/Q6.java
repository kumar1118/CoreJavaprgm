class Q6
{
	public static void main(String[] args) 
	{
		int num = Integer.parseInt(args[0]);
		int cube = num*num*num;
		System.out.println("cube of:"+num+"is:"+ cube);
	}
}