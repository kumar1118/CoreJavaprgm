class Q27 
{
	public static void main(String[] args) 
	{
		
		int i =  Integer.parseInt(args[0]); 
		int j =  Integer.parseInt(args[0]); 
		
		/*
		if(i == j)
		{
		System.out.println("Equal");
		}
		else
		{
		System.out.println("Not Equal");
		}
		*/

		/*
		String msg = (i == j) ? "equal" : "not equal";
		System.out.println(msg);
		*/
		System.out.println(i==j) ? "equal" : "not equal";
	}
}
