import java.util.Scanner;
class Q40
{
	public static void main(String[] args) 
	{
		int w, h, area;
      System.out.println("Enter w and h");
      Scanner in = new Scanner(System.in);
      w = in.nextInt();
	  h = in.nextInt();
		area = (w * h);
		System.out.println("area of Rectangle:"+area);
	}
}
