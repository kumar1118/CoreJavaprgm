class Q48
{
	public static void main(String[] args) 
	{
		int i = Integer.parseInt(args[0]);
		int j = Integer.parseInt(args[1]);
		int k = Integer.parseInt(args[2]);
		
		int p = i % 10;
		int q = j % 10;
		int r = k % 10;
		
		if(p == q || p == r || q == r )
		{
		System.out.println("true");
		}
		else
		{
		System.out.println("no symetry");
		}
	}
}
