import java.util.Scanner;
class Q39
{
	public static void main(String[] args) 
	{
		int b, h;
      System.out.println("Enter b and h");
      Scanner in = new Scanner(System.in);
      b = in.nextInt();
	  h = in.nextInt();
		double a = (double)(b * h)/2;
		System.out.println("area of triangle:"+a);
	}
}
