import java.util.Scanner;
class Q43
{
	public static void main(String[] args) 
	{
		int celsius;
      System.out.println("Enter value of celsius");
      Scanner in = new Scanner(System.in);
      celsius = in.nextInt();
	  double F = celsius * 9/5 + 32;
	  System.out.println(F);
	}
}
