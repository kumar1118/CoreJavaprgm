class Q35
{
	public static void main(String[] args) 
	{
		
		int num = Integer.parseInt(args[0]);
		System.out.println("without last three digit:"+num / 1000);
	}
}
