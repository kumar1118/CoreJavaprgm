class Q37 
{
	public static void main(String[] args) 
	{
		int i = Integer.parseInt(args[0]);
	    int j = Integer.parseInt(args[1]);
		System.out.println(i);
		System.out.println(j);
		System.out.println("...........");
		i = i + j;
		j = i - j;
		i = i - j;
		System.out.println(i);
		System.out.println(j);
	}
}
