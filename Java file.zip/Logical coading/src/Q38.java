import java.util.Scanner;
public class Q38 
	{
public static void main(String[] args) 
		{
	/*
		int i, fect=1;
		Scanner s=new Scanner(System.in);
	    System.out.println("Enter any number :");
		i =s.nextInt();
	    for(int j=1; j<=i; j++)
		{
		 fect= fect*j;
		}
		System.out.println("Factorial is :" + fect);
		*/
		int i = Integer.parseInt(args[0]);
		int factValue = 1;
		for(int j = i; j > 0; j--)
			{
			factValue *= j; //factValue = factValue * j;
			}
			System.out.println(factValue);
	}
}
/*Enter any number :
5
Factorial is :120

Enter any number :
8
Factorial is :40320

*/





