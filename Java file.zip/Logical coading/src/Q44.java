import java.util.Scanner;
class Q44
{
	public static void main(String[] args) 
	{
		int fahrenheit;
      System.out.println("Enter value of celsius");
      Scanner in = new Scanner(System.in);
      fahrenheit = in.nextInt();
	  double celsius = (double)(fahrenheit - 32) * 5 / 9;
	  System.out.println(celsius);
	}
}
