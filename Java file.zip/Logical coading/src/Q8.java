class Q8
{
	public static void main(String[] args) 
	{
		int i = Integer.parseInt(args[0]);
		switch(i)
		{
			case 0:
			System.out.println("zero");//opening and closing braces not required
			break;
			case 1:
			System.out.println("one");//opening and closing braces not required
			break;
			case 2:
			System.out.println("two");//opening and closing braces not required
			break;
			case 3:
			System.out.println("three");//opening and closing braces not required
			break;
			case 4:
			System.out.println("four");//opening and closing braces not required
			break;
			case 5:
			System.out.println("five");//opening and closing braces not required
			break;
			case 6:
			System.out.println("six");//opening and closing braces not required
			break;
			case 7:
			System.out.println("seven");//opening and closing braces not required
			break;
			case 8:
			System.out.println("eight");//opening and closing braces not required
			break;
			case 9:
			System.out.println("nine");//opening and closing braces not required
			break;
			default:
			System.out.println("input should be b/w 0 to 9");//opening and closing braces not required
			
		}
	}
}