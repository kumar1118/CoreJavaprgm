package pack2;
class  N
{
	public static void main(String[] args) 
	{
		M m1 = new M();
		System.out.println(m1.i);
		System.out.println(m1.j);
	}
}


//0
//0
//protected menber use through out the packege.