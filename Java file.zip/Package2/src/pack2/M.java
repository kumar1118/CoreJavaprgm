package pack2;
public class  M
{
	protected int i;
	public int j;
}

//proctected member are inherited any where.




