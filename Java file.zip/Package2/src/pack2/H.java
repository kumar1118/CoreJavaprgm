package pack2;
public class  H
{
	int x;
}
