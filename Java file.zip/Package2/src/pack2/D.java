package pack2;
class  D
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		System.out.println(a1.i);
		a1.test1();
		C c1 = new C();
		System.out.println(c1.i);
		c1.test1();
	}
}


//0
//from A-test1
//0
//from A-test1