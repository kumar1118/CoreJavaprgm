package pack2;
class  A
{
	int i;
	void test1()
	{
		System.out.println("from A-test1");
	}
	
}


//compilation successfull
//run time error becose of main method missing.