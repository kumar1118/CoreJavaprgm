package pack1;
class I
{
	private I()
	{
		System.out.println("I()");
	}
	 I(int i)
	{
		System.out.println("I(int)");
	}
}
class J extends I
{
	J()
	{
		super(10);
	}
}

//compilation successfully
//run time error becose of main method missing.
//if any class is private then can not develop a subclass, that is class is final
