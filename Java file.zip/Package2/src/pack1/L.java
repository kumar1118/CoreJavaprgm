package pack1;

class K

{
	private int i;
	private static int j;
	private viod test1()
	{
		System.out.println("from test1");
	}
	private static viod test2()
	{
		System.out.println("from test2");
	}
}
class L extends K
{
	public static void main(String[] args) 
	{

		System.out.println(L.j);
		L.test2();
		L obj = new L();
		System.out.println(obj.i);
		obj.test1();
		}
}


//private member of super class not inheriting to subclass.
//no inheritance is accessable to other class