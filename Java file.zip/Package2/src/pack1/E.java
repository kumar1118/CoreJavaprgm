package pack1;
class E
{
	private E()
	{
		System.out.println("E()");
	}
}
class F extends E
{
}

//E is a private and F can not extends.
//compilation error
//



