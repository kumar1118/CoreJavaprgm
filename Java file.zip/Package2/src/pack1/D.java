package pack1;
class C 
{
	private C()
	{
		System.out.println("C()");
	}
}
class D
{
	public static void main(String[] args) 
	{
		C c1 = new C();
		System.out.println("done");
	}
}


//compile time error.

//private constructor can not use in another class.
//private member is not using outside the class .



