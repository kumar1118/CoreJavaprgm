package pack1;
class G
{
	private G()
	{
		System.out.println("G()");
	}
	G(int i)
	{
		System.out.println("G(int)");
	}
}
class H extends G
{
}


///compilation error becose of default constructor with no argument cant be find.