package pack1;

class  A
{
	private int i;
	private static int j;
	private void test1()
	{
		System.out.println("from test1");
	}
	private static void test2()
	{
		System.out.println("from test2");
	}
	public static void main(String[] args) 
	{
		System.out.println(A.j);
		//A.test1();
		A.test2();
		A a1 = new A();
		System.out.println(a1.i);
		a1.test1();
	}
}

//private member we are using within the class A
//


