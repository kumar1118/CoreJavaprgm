package pack3;
import pack2.*;
class  L
{
	public static void main(String[] args) 
	{
		H h1 = new H();
		System.out.println("Hello World!");
	}
}
//Hello World!
//two types of importing
//* is the public class.
//