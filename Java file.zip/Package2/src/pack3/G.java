package pack3;

class  G
{
	public static void main(String[] args) 
	{
		pack2.E e1 = new pack2.E();
	}
}


//compile time error
//default scope cant be use another package.