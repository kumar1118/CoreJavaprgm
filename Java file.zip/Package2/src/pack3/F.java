package pack3;

class  F
{
	public static void main(String[] args) 
	{
		E e1 = new E();
	}
}


//error
//by default method can not be use in the another class.
//default access 