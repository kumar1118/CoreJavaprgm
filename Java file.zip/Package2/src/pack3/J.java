package pack3;
class  J extends pack2.H
{
	public static void main(String[] args) 
	{
		J obj = new J();
		System.out.println(obj.x);
	}
}

//compile tome error
//becose x is not a public.cannot be accessed outside the package.