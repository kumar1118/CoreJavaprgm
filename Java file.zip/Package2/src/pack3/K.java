package pack3;
import pack2.H;
class  K
{
	public static void main(String[] args) 
	{
		H h1 = new H();
		System.out.println("Hello World!");
	}
}


//hello world!