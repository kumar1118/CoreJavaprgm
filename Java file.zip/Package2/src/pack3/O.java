package pack3;
import pack2.M;
class  O
{
	public static void main(String[] args) 
	{
		M m1 = new M();
		System.out.println(m1.i);
		System.out.println(m1.j);
	}
}
 
//comjpile time error
//becose of i i
//member cant accesed outside the package.
//but protected member only inherited outside the package.