package pack3;
import pack2.M;
class  P extends M
{
	public static void main(String[] args) 
	{
		P p1 = new P();
		System.out.println(p1.i);
		System.out.println(p1.j);
		M m1 = new M();
		System.out.println(m1.i);
		System.out.println(m1.j);
	}
}


//compile time error