package pack3;
class  Q
{
	public static void main(String[] args) 
	{
		P p1 = new P();
		System.out.println(p1.i);
		System.out.println(p1.j);
	}
}

//compile time error
//becose of i is the protected member.
