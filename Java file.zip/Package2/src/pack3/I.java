package pack3;
class  I
{
	public static void main(String[] args) 
	{
		pack2.H h1 = new pack2.H();
		System.out.println(h1.x);
	}
}

//compile time error.
//x is not a public
