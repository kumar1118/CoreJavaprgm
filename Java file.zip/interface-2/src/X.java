class W
{
	void test()
	{
		System.out.println("from test()");
	}
}  
class X extends W
{
	void test(int i)
	{
		System.out.println("from test(int)");
	}
	public static void main(String[] args) 
	{
		X x1 = new X();
		x1.test();
		x1.test(20);
		System.out.println("done");
	}
}
