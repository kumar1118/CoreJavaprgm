abstract class S
{
	void test()
	{
		System.out.println("test()");
	}
	static void test(int i)
	{
		System.out.println("test(int)");
	}
	protected void test(int i, int j)
	{
		System.out.println("test(int, int)");
	}
	String test(int i, double j)
	{
		System.out.println("test(int, double)");
		return "abc";
	}
	abstract int test(boolean b);
}
class T extends S
{
	int test(boolean b)
	{
		System.out.println("test(boolean)");
		return 20;
	}
	public static void main(String[] args) 
	{
		T t1 = new T();
		t1.test();
		System.out.println("..........");
		T.test(20);
		System.out.println("..........");
		t1.test(20, 40);
		System.out.println("..........");
		System.out.println(t1.test(20, 30.43));
		t1.test(true);
	}
}
//


























