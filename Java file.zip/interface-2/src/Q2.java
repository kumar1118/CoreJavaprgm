class Q2 
{
	public static void main(String[] args) 
	{
		int marks = Integer.parseInt(args[0]);
		if (marks < 35)
		{
		System.out.println("fail");
		}
		else if (marks < 50)
		{
		System.out.println("just pass");
		}
		else if (marks < 59)
		{
		System.out.println("average");
		}
		else if (marks < 69)
		{
		System.out.println("above average");
		}
		else if (marks <= 85)
		{
		System.out.println("excellent");
		}
		else if (marks <= 100)
		{
		System.out.println("top lavel");
		}
	}
}
