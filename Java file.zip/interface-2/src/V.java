interface U
{
	void test();
	boolean test(int i);
}

class V implements U
{
	public void test()
	{
		System.out.println("from test()");
	}
	public boolean test(int i)
	{
		System.out.println("from test(int)");
		return true;
	}
	public static void main(String[] args) 
	{
		V v1 = new V();
		v1.test();
		System.out.println(v1.test(90));
		
	}
}
