interface G
{
	void test1();
}
interface H
{
	void test2();
}
interface I extends G, H
{
	void test3();
}
class J implements I
{
	public void test1()
	{
		System.out.println("from test1");
	}
	public void test2()
	{
		System.out.println("from test2");
	}
	public void test3()
	{
		System.out.println("from test3");
	}
	public static void main(String[] args) 
	{
		J obj = new J();
		obj.test1();
		obj.test2();
		obj.test3();
		System.out.println("Hello World!");
	}
}

//from test1
//from test2
//from test3
//Hello World!


//














