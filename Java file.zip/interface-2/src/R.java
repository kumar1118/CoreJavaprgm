class  R
{
	void test1()
	{
		System.out.println("test1()");
	}
	void test1(int i)
	{
		System.out.println("test1(int)");
	}
	
	public static void main(String[] args) 
	{
		R r1 = new R();
		r1.test1();
		System.out.println("..........");
		r1.test1(10);
		System.out.println("..........");
	}
}

//test1()
//.........
//test1(int)
//.........
//use different signature
//mnethod must be same
//while using private, protected or abstracted signature must be change.
//name should be same n diffrent signature


