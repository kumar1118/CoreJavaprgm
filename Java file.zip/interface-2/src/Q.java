interface K
{
	void test1();
}
interface L
{
	void test2();
}
interface M extends K, L
{
	void test3();
}
interface N
{
	void test4();
}

abstract class O 
{
	abstract void test5();
}
abstract class P extends O implements M, N
{
	public void test1()
	{
		System.out.println("from test1");
	}
	public void test2()
	{
		System.out.println("from test2");
	}
	public void test3()
	{
		System.out.println("from test3");
	}
}
class Q extends P
{
	public void test4()
	{
		System.out.println("from test4");
	}
	void test5()
	{
		System.out.println("from test5");
	}
	public static void main(String[] args) 
	{
		Q q1 = new Q();
		q1.test1();
		q1.test2();
		q1.test3();
		q1.test4();
		q1.test5();
		System.out.println("done");
	}
}


//from test1
//from test2
//from test3
//from test4
//from test5
//done









