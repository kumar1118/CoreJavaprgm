class D
{
}
class E
{
}
class F extends D, F
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
